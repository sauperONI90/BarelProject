﻿namespace barel_w_pro.forms
{
    partial class login
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblFullDateTime = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblFirstTag = new System.Windows.Forms.Label();
            this.lblIdTag = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtFirstName
            // 
            this.txtFirstName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFirstName.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtFirstName.ForeColor = System.Drawing.Color.White;
            this.txtFirstName.Location = new System.Drawing.Point(274, 158);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(250, 29);
            this.txtFirstName.TabIndex = 1;
            this.txtFirstName.TextChanged += new System.EventHandler(this.txtFirstName_TextChanged);
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.txtID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtID.ForeColor = System.Drawing.Color.White;
            this.txtID.Location = new System.Drawing.Point(274, 193);
            this.txtID.Name = "txtID";
            this.txtID.PasswordChar = '●';
            this.txtID.Size = new System.Drawing.Size(250, 29);
            this.txtID.TabIndex = 3;
            this.txtID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtID_KeyPress);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(215)))));
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(274, 228);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(250, 31);
            this.btnLogin.TabIndex = 5;
            this.btnLogin.Text = "התחברות";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lblFullDateTime
            // 
            this.lblFullDateTime.ForeColor = System.Drawing.Color.Gray;
            this.lblFullDateTime.Location = new System.Drawing.Point(114, 239);
            this.lblFullDateTime.Name = "lblFullDateTime";
            this.lblFullDateTime.Size = new System.Drawing.Size(154, 20);
            this.lblFullDateTime.TabIndex = 6;
            this.lblFullDateTime.Text = "Loading...";
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(179, 84);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(497, 71);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "חנות משחקים - הזדהות";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFirstTag
            // 
            this.lblFirstTag.ForeColor = System.Drawing.Color.Silver;
            this.lblFirstTag.Location = new System.Drawing.Point(530, 166);
            this.lblFirstTag.Name = "lblFirstTag";
            this.lblFirstTag.Size = new System.Drawing.Size(59, 23);
            this.lblFirstTag.TabIndex = 2;
            this.lblFirstTag.Text = "שם פרטי:";
            // 
            // lblIdTag
            // 
            this.lblIdTag.ForeColor = System.Drawing.Color.Silver;
            this.lblIdTag.Location = new System.Drawing.Point(530, 199);
            this.lblIdTag.Name = "lblIdTag";
            this.lblIdTag.Size = new System.Drawing.Size(74, 23);
            this.lblIdTag.TabIndex = 4;
            this.lblIdTag.Text = "תעודת זהות:";
            // 
            // login
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(877, 499);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblFirstTag);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.lblIdTag);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.lblFullDateTime);
            this.Name = "login";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblFullDateTime;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblFirstTag;
        private System.Windows.Forms.Label lblIdTag;
    }
}