using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class customerStore : Form
    {
        DataTable dtCart = new DataTable();
        private int initialCustomerId = 0;
        private string customerIdColumn = "customerId";
        private int lastSaleId = 0;
        private bool _isWorkerMode = false;
        private DataTable lastCompletedCart = null;

        public customerStore()
        {
            _isWorkerMode = true;
            InitializeComponent();
            SetupCart();

            if (textBox1 != null) textBox1.ReadOnly = false;
            if (textBox2 != null) textBox2.ReadOnly = false;

            if (comboBox1 != null)
            {
                comboBox1.Items.Clear();
                comboBox1.Items.Add("מזומן");
                comboBox1.Items.Add("אשראי");
                comboBox1.SelectedIndex = 0;
                comboBox1.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
            }

            ShowCardInputs(false);

            if (button1 != null) button1.Click += button1_Click;
            if (button2 != null) button2.Click += button2_Click;
            if (button3 != null) button3.Click += button3_Click;
        }

        public customerStore(int customerId) : this()
        {
            _isWorkerMode = false;
            initialCustomerId = customerId;
        }

        private void SetupCart()
        {
            try
            {
                dtCart = new DataTable("salesPreview");

                DataColumn idColumn = new DataColumn("OrderID", typeof(int));
                idColumn.AllowDBNull = true;
                dtCart.Columns.Add(idColumn);

                dtCart.Columns.Add("itemID", typeof(int));
                dtCart.Columns.Add("userID", typeof(int));
                dtCart.Columns.Add("userFirstName", typeof(string));
                dtCart.Columns.Add("game", typeof(string));
                dtCart.Columns.Add("ganre", typeof(string));
                dtCart.Columns.Add("price", typeof(double));
                dtCart.Columns.Add("TypeOfPayment", typeof(string));
                dtCart.Columns.Add("CardNum", typeof(string));
                dtCart.Columns.Add("CVV", typeof(string));
                dtCart.Columns.Add("Date", typeof(DateTime));
                dtCart.Columns.Add("Amount", typeof(int));
                dtCart.Columns.Add("total", typeof(double));

                if (dgvCart != null)
                {
                    dgvCart.AutoGenerateColumns = true;
                    dgvCart.DataSource = dtCart;
                    dgvCart.DefaultCellStyle.ForeColor = Color.Black;
                    dgvCart.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    dgvCart.MultiSelect = false;
                    dgvCart.AllowUserToAddRows = false;
                    dgvCart.ReadOnly = true;
                    dgvCart.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    ConfigureCartGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בהכנת הסל: " + ex.Message);
            }
        }

        private void ConfigureCartGrid()
        {
            if (dgvCart == null) return;

            if (dgvCart.Columns.Contains("OrderID"))
                dgvCart.Columns["OrderID"].HeaderText = "מספר הזמנה";

            if (dgvCart.Columns.Contains("itemID"))
                dgvCart.Columns["itemID"].Visible = false;

            if (dgvCart.Columns.Contains("ID"))
                dgvCart.Columns["ID"].Visible = false;

            if (dgvCart.Columns.Contains("CardNum"))
                dgvCart.Columns["CardNum"].Visible = false;

            if (dgvCart.Columns.Contains("CVV"))
                dgvCart.Columns["CVV"].Visible = false;

            if (dgvCart.Columns.Contains("userID"))
                dgvCart.Columns["userID"].HeaderText = "תז לקוח";

            if (dgvCart.Columns.Contains("userFirstName"))
                dgvCart.Columns["userFirstName"].HeaderText = "שם עובד";

            if (dgvCart.Columns.Contains("game"))
                dgvCart.Columns["game"].HeaderText = "שם משחק";

            if (dgvCart.Columns.Contains("ganre"))
                dgvCart.Columns["ganre"].HeaderText = "ז'אנר";

            if (dgvCart.Columns.Contains("price"))
                dgvCart.Columns["price"].HeaderText = "מחיר יחידה";

            if (dgvCart.Columns.Contains("TypeOfPayment"))
                dgvCart.Columns["TypeOfPayment"].HeaderText = "אמצעי תשלום";

            if (dgvCart.Columns.Contains("Date"))
                dgvCart.Columns["Date"].HeaderText = "תאריך";

            if (dgvCart.Columns.Contains("Amount"))
                dgvCart.Columns["Amount"].HeaderText = "כמות";

            if (dgvCart.Columns.Contains("total"))
                dgvCart.Columns["total"].HeaderText = "סה\"כ";
        }

        private void customerStore_Load(object sender, EventArgs e)
        {
            try
            {
                DataSet dsW = DbMain.ReturnDS("SELECT userId, userFirstName FROM users WHERE userRole = 'עובד'");
                if (dsW != null && dsW.Tables.Count > 0 && dsW.Tables[0].Rows.Count > 0 && cmbWorker != null)
                {
                    var tbl = dsW.Tables[0];
                    const string displayCol = "DisplayName";
                    if (!tbl.Columns.Contains(displayCol))
                        tbl.Columns.Add(displayCol, typeof(string));

                    foreach (DataRow r in tbl.Rows)
                    {
                        r[displayCol] = tbl.Columns.Contains("userFirstName") ? r["userFirstName"] : r["userId"];
                    }

                    cmbWorker.DataSource = tbl;
                    cmbWorker.DisplayMember = displayCol;
                    cmbWorker.ValueMember = tbl.Columns.Contains("userId") ? "userId" : tbl.Columns[0].ColumnName;
                    cmbWorker.DropDownStyle = ComboBoxStyle.DropDownList;
                }

                LoadGamesCombo();

                if (initialCustomerId > 0 && txtID != null)
                {
                    txtID.Text = initialCustomerId.ToString();
                    txtID.ReadOnly = true;
                }

                try
                {
                    var dsCust = DbMain.ReturnDS("SELECT * FROM [customer]");
                    if (dsCust != null && dsCust.Tables[0].Columns.Contains("userId"))
                        customerIdColumn = "userId";
                    else if (dsCust != null && dsCust.Tables[0].Columns.Contains("costumerId"))
                        customerIdColumn = "costumerId";
                }
                catch { }

                UpdateNextOrderIdDisplay();

                if (_isWorkerMode)
                {
                    if (txtID != null) txtID.Visible = false;
                    if (cmbCustomerID != null) cmbCustomerID.Visible = true;
                    if (label1 != null) label1.Text = "בחר לקוח:";
                    LoadCustomersCombo();
                }

                this.VisibleChanged += customerStore_VisibleChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינה: " + ex.Message);
            }
        }

        private void LoadCustomersCombo()
        {
            try
            {
                DataSet ds = DbMain.ReturnDS("SELECT * FROM customer");
                if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0) return;

                var dt = ds.Tables[0];

                string idCol = dt.Columns.Contains("userId") ? "userId"
                             : dt.Columns.Contains("customerId") ? "customerId"
                             : dt.Columns.Contains("costumerId") ? "costumerId"
                             : dt.Columns[0].ColumnName;

                string firstCol = dt.Columns.Contains("customerFirstName") ? "customerFirstName"
                                : dt.Columns.Contains("costumerFirstname") ? "costumerFirstname"
                                : dt.Columns.Contains("customerFirstname") ? "customerFirstname"
                                : "";
                string lastCol = dt.Columns.Contains("customerLastName") ? "customerLastName"
                                : dt.Columns.Contains("costumerLastName") ? "costumerLastName"
                                : "";

                if (!dt.Columns.Contains("displayName"))
                    dt.Columns.Add("displayName", typeof(string));

                foreach (DataRow row in dt.Rows)
                {
                    string first = firstCol != "" ? row[firstCol]?.ToString() ?? "" : "";
                    string last = lastCol != "" ? row[lastCol]?.ToString() ?? "" : "";
                    row["displayName"] = $"{row[idCol]} - {first} {last}".Trim();
                }

                cmbCustomerID.DataSource = dt;
                cmbCustomerID.DisplayMember = "displayName";
                cmbCustomerID.ValueMember = idCol;
                cmbCustomerID.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת רשימת לקוחות: " + ex.Message);
            }
        }

        private int GetSelectedCustomerId()
        {
            if (_isWorkerMode)
            {
                if (cmbCustomerID != null && cmbCustomerID.SelectedValue != null)
                    return Convert.ToInt32(cmbCustomerID.SelectedValue);
                return 0;
            }
            return int.TryParse(txtID?.Text, out int id) ? id : 0;
        }

        private void UpdateNextOrderIdDisplay()
        {
            if (textBox3 != null)
            {
                try
                {
                    DataSet dsOrder = DbMain.ReturnDS("SELECT MAX(OrderID) FROM sales");
                    if (dsOrder != null && dsOrder.Tables.Count > 0 && dsOrder.Tables[0].Rows.Count > 0 && dsOrder.Tables[0].Rows[0][0] != DBNull.Value)
                    {
                        int maxId = Convert.ToInt32(dsOrder.Tables[0].Rows[0][0]);
                        textBox3.Text = (maxId + 1).ToString();
                    }
                    else
                    {
                        textBox3.Text = "1";
                    }
                    textBox3.ReadOnly = true;
                }
                catch
                {
                    textBox3.Text = "-";
                }
            }
        }

        private void LoadGamesCombo()
        {
            try
            {
                DataSet dsG = DbMain.ReturnDS("SELECT itemID, gameName, price, quantity, ganre FROM GAMES");
                if (dsG != null && dsG.Tables.Count > 0 && cmbGames != null)
                {
                    int previousIndex = cmbGames.SelectedIndex;
                    object previousValue = cmbGames.SelectedValue;
                    cmbGames.DataSource = null;
                    cmbGames.DataSource = dsG.Tables[0];
                    cmbGames.DisplayMember = "gameName";
                    cmbGames.ValueMember = "itemID";
                    cmbGames.DropDownStyle = ComboBoxStyle.DropDownList;
                    if (previousValue != null && previousValue != DBNull.Value)
                    {
                        try { cmbGames.SelectedValue = previousValue; }
                        catch
                        {
                            if (previousIndex >= 0 && previousIndex < cmbGames.Items.Count)
                                cmbGames.SelectedIndex = previousIndex;
                        }
                    }
                    else if (previousIndex >= 0 && previousIndex < cmbGames.Items.Count)
                    {
                        cmbGames.SelectedIndex = previousIndex;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת משחקים: " + ex.Message);
            }
        }

        private void customerStore_Activated(object sender, EventArgs e)
        {
            try
            {
                LoadGamesCombo();
                if (cmbGames != null && cmbGames.SelectedIndex >= 0)
                    cmbGames_SelectedIndexChanged(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה ברענון הנתונים: " + ex.Message);
            }
        }

        private void customerStore_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible && this.IsHandleCreated)
            {
                try
                {
                    LoadGamesCombo();
                    if (cmbGames != null && cmbGames.SelectedIndex >= 0)
                        cmbGames_SelectedIndexChanged(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("שגיאה ברענון הנתונים: " + ex.Message);
                }
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1 != null && comboBox1.SelectedItem != null)
                ShowCardInputs(comboBox1.SelectedItem.ToString() == "אשראי");
        }

        private void ShowCardInputs(bool show)
        {
            if (label8 != null) label8.Visible = show;
            if (textBox1 != null) { textBox1.Visible = show; if (!show) textBox1.Text = ""; }
            if (label9 != null) label9.Visible = true;
            if (dateTimePicker1 != null) dateTimePicker1.Visible = true;
            if (label6 != null) label6.Visible = show;
            if (textBox2 != null) { textBox2.Visible = show; if (!show) textBox2.Text = ""; }
        }

        private void cmbGames_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbGames?.SelectedItem is DataRowView row)
            {
                if (txtGenre != null) txtGenre.Text = row["ganre"].ToString();
                if (txtPrice != null) txtPrice.Text = row["price"].ToString();
                int itemID = Convert.ToInt32(row["itemID"]);
                int stock = GetStockFromDB(itemID);
                if (lblStockStatus != null)
                {
                    lblStockStatus.Text = $"מלאי זמין: {stock}";
                    lblStockStatus.ForeColor = stock > 0 ? Color.SpringGreen : Color.Red;
                }
                if (numAmount != null)
                {
                    numAmount.Maximum = stock;
                    numAmount.Value = stock > 0 ? 1 : 0;
                }
            }
        }

        private int GetStockFromDB(int itemID)
        {
            try
            {
                DataSet ds = DbMain.ReturnDS("SELECT quantity FROM GAMES WHERE itemID = " + itemID);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    return Convert.ToInt32(ds.Tables[0].Rows[0]["quantity"]);
            }
            catch { }
            return 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cmbGames == null || numAmount == null) return;

            int custID = GetSelectedCustomerId();
            if (custID == 0)
            {
                MessageBox.Show(_isWorkerMode ? "נא לבחור לקוח" : "נא להזין ת.ז תקינה");
                return;
            }

            if (cmbGames.SelectedIndex == -1) { MessageBox.Show("נא לבחור משחק"); return; }
            if (numAmount.Value <= 0) { MessageBox.Show("נא לבחור כמות גדולה מ-0"); return; }

            DataRowView row = (DataRowView)cmbGames.SelectedItem;

            int availableStock = 0;
            try
            {
                int itemID = Convert.ToInt32(row["itemID"]);
                DataSet liveDb = DbMain.ReturnDS($"SELECT quantity FROM GAMES WHERE itemID = {itemID}");
                if (liveDb != null && liveDb.Tables.Count > 0 && liveDb.Tables[0].Rows.Count > 0)
                    availableStock = Convert.ToInt32(liveDb.Tables[0].Rows[0]["quantity"]);
                else
                    availableStock = Convert.ToInt32(row["quantity"]);
            }
            catch
            {
                try { availableStock = Convert.ToInt32(row["quantity"]); } catch { availableStock = 0; }
            }

            int requestedQty = (int)numAmount.Value;
            if (requestedQty > availableStock)
            {
                MessageBox.Show($"שגיאה: הכמות המבוקשת ({requestedQty}) עולה על המלאי הזמין ({availableStock}).\n\nאנא בחר כמות עד {availableStock} יחידות.",
                    "כמות לא זמינה", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int workerId = 0;
            string workerName = "";
            if (cmbWorker != null && cmbWorker.SelectedValue != null) workerId = Convert.ToInt32(cmbWorker.SelectedValue);
            if (cmbWorker != null && cmbWorker.Text != null) workerName = cmbWorker.Text.Trim();

            bool isCreditCard = comboBox1 != null && comboBox1.SelectedItem != null && comboBox1.SelectedItem.ToString() == "אשראי";
            string paymentType = isCreditCard ? "אשראי" : "מזומן";
            string cardNum = isCreditCard && textBox1 != null ? textBox1.Text.Trim() : "0";
            string cvv = isCreditCard && textBox2 != null ? textBox2.Text.Trim() : "0";

            double price = Convert.ToDouble(row["price"]);
            int amount = requestedQty;
            double total = price * amount;

            DataRow cartRow = dtCart.NewRow();

            int orderId = 0;
            if (textBox3 != null && int.TryParse(textBox3.Text, out int parsedId)) orderId = parsedId;

            if (dtCart.Columns.Contains("OrderID")) cartRow["OrderID"] = orderId;
            if (dtCart.Columns.Contains("itemID")) cartRow["itemID"] = Convert.ToInt32(row["itemID"]);
            if (dtCart.Columns.Contains("userID")) cartRow["userID"] = workerId;
            if (dtCart.Columns.Contains("userFirstName")) cartRow["userFirstName"] = workerName;
            if (dtCart.Columns.Contains("game")) cartRow["game"] = row["gameName"].ToString();
            if (dtCart.Columns.Contains("ganre")) cartRow["ganre"] = row["ganre"].ToString();
            if (dtCart.Columns.Contains("price")) cartRow["price"] = price;
            if (dtCart.Columns.Contains("TypeOfPayment")) cartRow["TypeOfPayment"] = paymentType;
            if (dtCart.Columns.Contains("CardNum")) cartRow["CardNum"] = cardNum;
            if (dtCart.Columns.Contains("CVV")) cartRow["CVV"] = cvv;
            if (dtCart.Columns.Contains("Date")) cartRow["Date"] = dateTimePicker1 != null ? dateTimePicker1.Value : DateTime.Now;
            if (dtCart.Columns.Contains("Amount")) cartRow["Amount"] = amount;
            if (dtCart.Columns.Contains("total")) cartRow["total"] = total;

            dtCart.Rows.Add(cartRow);
            UpdateTotalDisplay();
            MessageBox.Show($"הפריט '{row["gameName"]}' נוסף לסל בהצלחה!", "נוסף לסל", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void UpdateTotalDisplay()
        {
            if (lblTotal == null) return;

            double sum = 0;
            foreach (DataRow r in dtCart.Rows)
            {
                sum += Convert.ToDouble(r["total"]);
            }

            lblTotal.Text = $"סה\"כ: {sum:N2} ₪";
        }

        private void RefreshStockDisplay()
        {
            try
            {
                DataSet dsG = DbMain.ReturnDS("SELECT itemID, gameName, price, quantity, ganre FROM GAMES");
                if (dsG == null || dsG.Tables.Count == 0 || cmbGames == null) return;

                cmbGames.DataSource = null;
                cmbGames.DataSource = dsG.Tables[0];
                cmbGames.DisplayMember = "gameName";
                cmbGames.ValueMember = "itemID";
                cmbGames.DropDownStyle = ComboBoxStyle.DropDownList;

                if (cmbGames.Items.Count > 0)
                    cmbGames.SelectedIndex = 0;

                if (cmbGames.SelectedItem is DataRowView selectedRow)
                {
                    int itemID = Convert.ToInt32(selectedRow["itemID"]);
                    int stock = GetStockFromDB(itemID);

                    if (lblStockStatus != null)
                    {
                        lblStockStatus.Text = $"מלאי זמין: {stock}";
                        lblStockStatus.ForeColor = stock > 0 ? Color.SpringGreen : Color.Red;
                    }
                    if (numAmount != null)
                    {
                        numAmount.Maximum = stock;
                        numAmount.Value = stock > 0 ? 1 : 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה ברענון מלאי: " + ex.Message);
            }
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            if (dtCart.Rows.Count == 0)
            {
                MessageBox.Show("הסל ריק!");
                return;
            }

            if (cmbWorker == null || cmbWorker.SelectedValue == null)
            {
                MessageBox.Show("נא לבחור עובד מבצע.");
                return;
            }

            if (comboBox1 != null && comboBox1.SelectedItem?.ToString() == "אשראי" && !ValidateCardInputs(out string error))
            {
                MessageBox.Show(error);
                return;
            }

            try
            {
                int customerId = GetSelectedCustomerId();
                if (customerId == 0)
                {
                    MessageBox.Show(_isWorkerMode ? "נא לבחור לקוח" : "נא להזין ת.ז תקינה");
                    return;
                }
                int workerId = Convert.ToInt32(cmbWorker.SelectedValue);

                if (dtCart.Rows.Count > 0 && dtCart.Columns.Contains("OrderID") && dtCart.Rows[0]["OrderID"] != DBNull.Value)
                {
                    lastSaleId = Convert.ToInt32(dtCart.Rows[0]["OrderID"]);
                }

                string checkSql = $"SELECT COUNT(*) FROM [customer] WHERE [{customerIdColumn}] = {customerId}";
                DataSet dsRes = DbMain.ReturnDS(checkSql);
                int count = Convert.ToInt32(dsRes.Tables[0].Rows[0][0]);

                if (count == 0)
                {
                    MessageBox.Show($"לקוח {customerId} לא רשום במערכת.");
                    return;
                }

                string customerNameSql = $"SELECT * FROM [customer] WHERE [{customerIdColumn}] = {customerId}";
                DataSet dsCustomer = DbMain.ReturnDS(customerNameSql);
                string customerName = "";

                if (dsCustomer != null && dsCustomer.Tables.Count > 0 && dsCustomer.Tables[0].Rows.Count > 0)
                {
                    DataRow custRow = dsCustomer.Tables[0].Rows[0];
                    if (custRow.Table.Columns.Contains("costumerFirstname"))
                        customerName = custRow["costumerFirstname"].ToString();
                    else if (custRow.Table.Columns.Contains("customerFirstname"))
                        customerName = custRow["customerFirstname"].ToString();
                    else if (custRow.Table.Columns.Contains("customerFirstName"))
                        customerName = custRow["customerFirstName"].ToString();
                }

                string workerNameSql = $"SELECT userFirstName FROM [users] WHERE [userId] = {workerId}";
                DataSet dsWorker = DbMain.ReturnDS(workerNameSql);
                string workerName = "";

                if (dsWorker != null && dsWorker.Tables.Count > 0 && dsWorker.Tables[0].Rows.Count > 0)
                {
                    workerName = dsWorker.Tables[0].Rows[0]["userFirstName"].ToString();
                }

                bool isCreditCard = comboBox1 != null && comboBox1.SelectedItem != null && comboBox1.SelectedItem.ToString() == "אשראי";
                string paymentType = isCreditCard ? "אשראי" : "מזומן";
                string cardNum = isCreditCard && textBox1 != null ? textBox1.Text.Trim() : "0";
                string cvv = isCreditCard && textBox2 != null ? textBox2.Text.Trim() : "0";

                string safeWorkerName = workerName.Replace("'", "''");

                foreach (DataRow cartItem in dtCart.Rows)
                {
                    DateTime saleDate = DateTime.Now;
                    if (dtCart.Columns.Contains("Date") && cartItem["Date"] != DBNull.Value)
                        saleDate = Convert.ToDateTime(cartItem["Date"]);
                    else if (dateTimePicker1 != null)
                        saleDate = dateTimePicker1.Value;

                    int itemID = Convert.ToInt32(cartItem["itemID"]);
                    string gameName = cartItem["game"].ToString().Replace("'", "''");
                    string genre = cartItem["ganre"].ToString().Replace("'", "''");
                    double price = Convert.ToDouble(cartItem["price"]);
                    int amount = Convert.ToInt32(cartItem["Amount"]);
                    double total = Convert.ToDouble(cartItem["total"]);

                    string priceSql = price.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    string totalSql = total.ToString(System.Globalization.CultureInfo.InvariantCulture);

                    string insertSql = $@"INSERT INTO sales
                        (costumerID, userFirstName, game, ganre, price, TypeOfPayment, CardNum, CVV, [Date], Amount, total)
                        VALUES
                        ({customerId}, '{safeWorkerName}', '{gameName}', '{genre}', {priceSql}, '{paymentType}', '{cardNum}', '{cvv}', #{saleDate:MM/dd/yyyy HH:mm:ss}#, {amount}, {totalSql})";

                    try
                    {
                        DbMain.InsDelUpd(insertSql);

                        string updateStockSql = $"UPDATE GAMES SET quantity = quantity - {amount} WHERE itemID = {itemID}";
                        int rows = DbMain.InsDelUpdRows(updateStockSql);
                        if (rows == 0)
                        {
                            MessageBox.Show($"אזהרה: עדכון מלאי לא מצא פריט עם itemID={itemID}\nSQL: {updateStockSql}",
                                "בעיה בעדכון מלאי", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"שגיאה בשמירת שורה למסד הנתונים:\n{ex.Message}\n\nשאילתה שניסתה לרוץ:\n{insertSql}",
                                        "שגיאת SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                lastCompletedCart = dtCart.Copy();

                MessageBox.Show($"הרכישה בוצעה בהצלחה!\nמספר הזמנה: {lastSaleId}\nלקוח: {customerName}\nעובד מבצע: {workerName}", "הצלחה", MessageBoxButtons.OK, MessageBoxIcon.Information);

                dtCart.Clear();
                UpdateTotalDisplay();
                RefreshStockDisplay();
                UpdateNextOrderIdDisplay();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בביצוע הרכישה: " + ex.Message, "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvCart == null || dgvCart.CurrentRow == null)
                {
                    MessageBox.Show("אנא בחר פריט בסל כדי למחוק.");
                    return;
                }

                DataRowView drv = dgvCart.CurrentRow.DataBoundItem as DataRowView;
                if (drv == null)
                {
                    MessageBox.Show("לא ניתן לקרוא את השורה הנבחרת למחיקה.");
                    return;
                }

                string itemName = drv.Row.Table.Columns.Contains("game") ? drv["game"].ToString() : "(פריט)";
                DialogResult confirm = MessageBox.Show($"האם למחוק את הפריט '{itemName}' מהסל?", "אישור מחיקה", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm != DialogResult.Yes) return;

                dtCart.Rows.Remove(drv.Row);
                UpdateTotalDisplay();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה במחיקה: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtCart.Rows.Count == 0)
                {
                    MessageBox.Show("הסל כבר ריק.");
                    return;
                }

                var confirm = MessageBox.Show("האם לרוקן את כל הסל?", "אישור ריקון סל", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm != DialogResult.Yes) return;

                dtCart.Clear();
                UpdateTotalDisplay();
                MessageBox.Show("הסל רוקן בהצלחה!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בריקון הסל: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (lastSaleId == 0)
                {
                    MessageBox.Show("לא נמצאה רכישה אחרונה.\n\nבצע רכישה קודם על ידי לחיצה על 'ביצוע רכישה'.");
                    return;
                }

                var receiptForm = new receipt(lastSaleId, lastCompletedCart);
                receiptForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בהצגת קבלה: " + ex.Message);
            }
        }

        private void lblTotal_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }

        private bool ValidateCardInputs(out string error)
        {
            error = string.Empty;

            if (textBox1 == null || string.IsNullOrWhiteSpace(textBox1.Text))
            {
                error = "נא להזין מספר כרטיס אשראי.";
                return false;
            }

            if (textBox2 == null || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                error = "נא להזין קוד CVV.";
                return false;
            }

            if (textBox1.Text.Length < 8 || textBox1.Text.Length > 19 || !textBox1.Text.All(char.IsDigit))
            {
                error = "מספר כרטיס אשראי לא תקין.";
                return false;
            }

            if (textBox2.Text.Length < 3 || textBox2.Text.Length > 4 || !textBox2.Text.All(char.IsDigit))
            {
                error = "קוד CVV לא תקין.";
                return false;
            }

            return true;
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
