﻿using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class GamesByprofitabilityReports : Form
    {
        private const string QueryName = "GAMESSALESQ";

        private DataTable reportTable;
        private string codeFilter = string.Empty;
        private string nameFilter = string.Empty;
        private bool showUnsoldOnly;

        public GamesByprofitabilityReports()
        {
            InitializeComponent();
            this.Load += GamesByprofitabilityReports_Load;

            if (textBox10 != null)
            {
                textBox10.ReadOnly = true;
                textBox10.TabStop = false;
            }

            if (listView1 != null)
            {
                listView1.View = View.Details;
                listView1.GridLines = true;
                listView1.FullRowSelect = true;
                listView1.RightToLeft = RightToLeft.Yes;
                listView1.RightToLeftLayout = true;
            }

            if (button1 != null) button1.Click += button1_Click;
            if (button2 != null) button2.Click += button2_Click;
            if (button3 != null) button3.Click += button3_Click;
            if (button4 != null) button4.Click += button4_Click;
            if (textBox1 != null) textBox1.KeyDown += textBox1_KeyDown;
            if (textBox2 != null) textBox2.KeyDown += textBox2_KeyDown;
        }

        private void GamesByprofitabilityReports_Load(object sender, EventArgs e)
        {
            LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                DataSet ds = DbMain.ReturnDS("SELECT * FROM " + QueryName);
                if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                {
                    reportTable = null;
                    ClearListView();
                    MessageBox.Show("לא נמצאו נתונים להצגה בדוח.");
                    return;
                }

                reportTable = ds.Tables[0].Copy();
                RefreshReportView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת דוח רווחיות המשחקים: " + ex.Message, "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshReportView()
        {
            try
            {
                if (reportTable == null)
                {
                    ClearListView();
                    return;
                }

                var rows = reportTable.AsEnumerable();

                string itemIdColumn = FindColumn(reportTable, "itemID", "ID", "gameID");
                string gameNameColumn = FindColumn(reportTable, "gameName", "name", "שם משחק");
                string soldColumn = FindColumn(reportTable, "Amount", "soldAmount", "totalSold", "quantitySold", "sold", "נמכר");
                string profitColumn = FindColumn(reportTable, "profitability", "profit", "totalprofit", "netprofit", "רווחיות", "רווח");
                string totalColumn = FindColumn(reportTable, "total", "totalsales", "revenue", "סהכ", "הכנסות");

                if (!string.IsNullOrWhiteSpace(codeFilter) && !string.IsNullOrWhiteSpace(itemIdColumn))
                {
                    rows = rows.Where(r => Convert.ToString(r[itemIdColumn]).IndexOf(codeFilter, StringComparison.OrdinalIgnoreCase) >= 0);
                }

                if (!string.IsNullOrWhiteSpace(nameFilter) && !string.IsNullOrWhiteSpace(gameNameColumn))
                {
                    rows = rows.Where(r => Convert.ToString(r[gameNameColumn]).IndexOf(nameFilter, StringComparison.OrdinalIgnoreCase) >= 0);
                }

                if (showUnsoldOnly && !string.IsNullOrWhiteSpace(soldColumn))
                {
                    rows = rows.Where(r => IsZeroOrEmpty(r[soldColumn]));
                }

                if (!string.IsNullOrWhiteSpace(profitColumn))
                {
                    rows = rows.OrderByDescending(r => ToDecimal(r[profitColumn]));
                }
                else if (!string.IsNullOrWhiteSpace(totalColumn))
                {
                    rows = rows.OrderByDescending(r => ToDecimal(r[totalColumn]));
                }

                DataTable displayTable = reportTable.Clone();
                foreach (DataRow row in rows)
                {
                    displayTable.ImportRow(row);
                }

                BindToListView(displayTable);
                UpdateUnsoldButtonText();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בעדכון תצוגת הדוח: " + ex.Message, "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BindToListView(DataTable displayTable)
        {
            listView1.BeginUpdate();
            try
            {
                listView1.Items.Clear();
                listView1.Columns.Clear();

                foreach (DataColumn column in displayTable.Columns)
                {
                    string columnKey = string.IsNullOrWhiteSpace(column.ColumnName) ? column.Caption : column.ColumnName;
                    ColumnHeader header = listView1.Columns.Add(columnKey, GetHeaderText(column.ColumnName), 120);
                    header.TextAlign = GetColumnAlignment(column.ColumnName);
                }

                foreach (DataRow row in displayTable.Rows)
                {
                    ListViewItem item = null;

                    foreach (ColumnHeader column in listView1.Columns)
                    {
                        string value = FormatCellValue(row[column.Name]);

                        if (item == null)
                            item = new ListViewItem(value);
                        else
                            item.SubItems.Add(value);
                    }

                    ApplyProfitRowStyle(item, displayTable, row);

                    if (item != null)
                        listView1.Items.Add(item);
                }

                foreach (ColumnHeader column in listView1.Columns)
                {
                    column.Width = -2;
                }
            }
            finally
            {
                listView1.EndUpdate();
            }
        }

        private void ClearListView()
        {
            listView1.BeginUpdate();
            try
            {
                listView1.Items.Clear();
                listView1.Columns.Clear();
            }
            finally
            {
                listView1.EndUpdate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showUnsoldOnly = !showUnsoldOnly;
            RefreshReportView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            nameFilter = textBox1 != null ? textBox1.Text.Trim() : string.Empty;
            RefreshReportView();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RefreshReportView();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            codeFilter = textBox2 != null ? textBox2.Text.Trim() : string.Empty;
            RefreshReportView();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter)
                return;

            e.SuppressKeyPress = true;
            e.Handled = true;
            button2_Click(sender, EventArgs.Empty);
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter)
                return;

            e.SuppressKeyPress = true;
            e.Handled = true;
            button4_Click(sender, EventArgs.Empty);
        }

        private void UpdateUnsoldButtonText()
        {
            if (button1 == null)
                return;

            button1.Text = showUnsoldOnly
                ? "הצג את כל המשחקים"
                : "הצג רק משחקים שלא נמכרו";
        }

        private bool IsZeroOrEmpty(object value)
        {
            if (value == null || value == DBNull.Value)
                return true;

            return ToDecimal(value) == 0m;
        }

        private decimal ToDecimal(object value)
        {
            if (value == null || value == DBNull.Value)
                return 0m;

            decimal decimalValue;
            string text = value.ToString().Trim();
            if (decimal.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out decimalValue) ||
                decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out decimalValue))
            {
                return decimalValue;
            }

            return 0m;
        }

        private void ApplyProfitRowStyle(ListViewItem item, DataTable table, DataRow row)
        {
            if (item == null || table == null || row == null)
                return;

            string profitColumn = FindColumn(table,
                "profitability",
                "profit",
                "totalprofit",
                "netprofit",
                "רווחיות",
                "רווח");

            if (string.IsNullOrWhiteSpace(profitColumn) || row[profitColumn] == DBNull.Value)
                return;

            decimal profitValue;
            string text = row[profitColumn].ToString().Trim();
            if (!(decimal.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out profitValue) ||
                  decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out profitValue)))
            {
                return;
            }

            if (profitValue < 0)
            {
                item.BackColor = Color.MistyRose;
                item.ForeColor = Color.DarkRed;
            }
            else if (profitValue > 0)
            {
                item.BackColor = Color.Honeydew;
                item.ForeColor = Color.DarkGreen;
            }
        }

        private string GetHeaderText(string columnName)
        {
            switch (columnName)
            {
                case "itemID": return "קוד משחק";
                case "gameName": return "שם משחק";
                case "ganre":
                case "GAMES_ganre": return "ז'אנר";
                case "quantity": return "מלאי";
                case "Amount":
                case "soldAmount":
                case "totalSold":
                case "quantitySold": return "כמות שנמכרה";
                case "price":
                case "GAMES_price": return "מחיר";
                case "total":
                case "revenue":
                case "totalRevenue": return "הכנסה כוללת";
                case "profit":
                case "totalProfit":
                case "netProfit":
                case "profitability": return "רווחיות";
                case "supplierID": return "קוד ספק";
                case "supplierChainName": return "שם ספק";
                default: return columnName;
            }
        }

        private HorizontalAlignment GetColumnAlignment(string columnName)
        {
            switch (columnName)
            {
                case "gameName":
                case "game":
                case "ganre":
                case "GAMES_ganre":
                case "sales_ganre":
                case "supplierChainName":
                    return HorizontalAlignment.Right;
                default:
                    return HorizontalAlignment.Center;
            }
        }

        private string FormatCellValue(object value)
        {
            if (value == null || value == DBNull.Value)
                return string.Empty;

            if (value is DateTime)
                return ((DateTime)value).ToString("dd/MM/yyyy HH:mm");

            decimal decimalValue;
            string text = value.ToString();
            if (decimal.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out decimalValue) ||
                decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out decimalValue))
            {
                return decimalValue % 1 == 0 ? decimalValue.ToString("0") : decimalValue.ToString("0.##");
            }

            return text;
        }

        private string FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string candidate in columnNames)
            {
                foreach (DataColumn column in table.Columns)
                {
                    if (string.Equals(column.ColumnName, candidate, StringComparison.OrdinalIgnoreCase))
                        return column.ColumnName;
                }
            }

            return null;
        }
    }
}
