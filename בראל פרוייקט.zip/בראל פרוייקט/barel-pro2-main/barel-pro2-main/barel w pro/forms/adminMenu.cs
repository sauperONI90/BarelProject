﻿using System;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class adminMenu : Form
    {
        public adminMenu()
        {
            InitializeComponent();
        }

        private void BtnCustomers_Click(object sender, EventArgs e)
        {
            // פתח טופס לקוחות (ודא שהשם נכון)
            try { new CustomersForm().Show(); } catch { MessageBox.Show("טופס לקוחות לא נמצא"); }
        }

        private void BtnWorkers_Click(object sender, EventArgs e)
        {
            new worker().Show();
        }

        private void BtnSales_Click(object sender, EventArgs e)
        {
            try { new customerStore().Show(); } catch { MessageBox.Show("טופס מכירות לא נמצא"); }
        }

        private void BtnPurchases_Click(object sender, EventArgs e)
        {
            try { new buyFromSupplierForm().Show(); } catch { MessageBox.Show("טופס רכש לא נמצא"); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try { new Games().Show(); } catch { MessageBox.Show("טופס משחקים לא נמצא"); }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Application.OpenForms["login"] != null)
                Application.OpenForms["login"].Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Supplier().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try { new PurchaseHistoryReport().Show(); } catch { MessageBox.Show("טופס דוח היסטוריית רכישות לא נמצא"); }
        }

        private void adminMenu_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { new InventoryReport().Show(); } catch { MessageBox.Show("טופס דוח מלאי לא נמצא"); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try { new catalouge().Show(); } catch { MessageBox.Show("טופס קטלוג לא נמצא"); }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try { new GamesByprofitabilityReports().Show(); } catch { MessageBox.Show("טופס דוח GAMESSALESQ לא נמצא"); }
        }
    }
}