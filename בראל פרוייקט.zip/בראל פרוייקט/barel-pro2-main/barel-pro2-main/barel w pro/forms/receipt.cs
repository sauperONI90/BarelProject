﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class receipt : Form
    {
        private int saleId;
        private DataTable cartData;

        public receipt()
        {
            InitializeComponent();
        }

        public receipt(int saleId) : this()
        {
            this.saleId = saleId;
            LoadReceiptData();
        }

        public receipt(int saleId, DataTable cartData) : this()
        {
            this.saleId = saleId;
            this.cartData = cartData;
            LoadReceiptData();
        }

        private void LoadReceiptData()
        {
            try
            {
                DataTable salesData = null;

                if (cartData != null && cartData.Rows.Count > 0)
                {
                    salesData = cartData.Copy();
                }
                else
                {
                    // מסננים לפי ה-OrderID של הרכישה שהעברנו בחלון הקודם
                    string sql = $"SELECT * FROM sales WHERE OrderID = {saleId}";
                    DataSet ds = DbMain.ReturnDS(sql);

                    if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                    {
                        MessageBox.Show("לא נמצאו נתונים עבור קבלה זו.");
                        this.Close();
                        return;
                    }

                    salesData = ds.Tables[0];
                }

                var firstRow = salesData.Rows[0];

                // --- עדכון תוויות עיליות (Labels) ---
                if (label21 != null) // מציגים את מספר הקבלה למעלה
                {
                    label21.Text = $"מספר הזמנה: {saleId}";
                    // אופציונלי - להגדיל גופן אם צריך
                    // label21.Font = new Font(label21.Font.FontFamily, 12, FontStyle.Bold); 
                }

                // הצגת תאריך הרכישה
                if (firstRow.Table.Columns.Contains("Date") && firstRow["Date"] != DBNull.Value)
                {
                    DateTime purchaseDate = Convert.ToDateTime(firstRow["Date"]);
                    label1.Text = $"תאריך רכישה: {purchaseDate:dd/MM/yyyy HH:mm}";
                }

                // הצגת אמצעי תשלום
                string paymentType = firstRow.Table.Columns.Contains("TypeOfPayment") ? firstRow["TypeOfPayment"].ToString() : "לא ידוע";
                label7.Text = $"אמצעי תשלום: {paymentType}";

                // חישוב סכום כולל
                double totalAmount = 0;
                foreach (DataRow row in salesData.Rows)
                {
                    if (row.Table.Columns.Contains("total") && row["total"] != DBNull.Value)
                    {
                        totalAmount += Convert.ToDouble(row["total"]);
                    }
                }
                label5.Text = $"סה\"כ לתשלום: {totalAmount:N2} ₪";

                // --- חיבור הטבלה ---
                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = salesData;
                dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
                
                // עיצוב הטבלה
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.AllowUserToDeleteRows = false;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.MultiSelect = false;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                // --- הסתרת עמודות אישיות / לא רלוונטיות ---
                if (dataGridView1.Columns.Contains("ID")) 
                    dataGridView1.Columns["ID"].Visible = false;
                    
                if (dataGridView1.Columns.Contains("costumerID"))
                    dataGridView1.Columns["costumerID"].Visible = false;
                    
                if (dataGridView1.Columns.Contains("CardNum"))
                    dataGridView1.Columns["CardNum"].Visible = false;
                    
                if (dataGridView1.Columns.Contains("CVV"))
                    dataGridView1.Columns["CVV"].Visible = false;

                // --- שינוי שמות העמודות שיוצגו בעברית (כמו בסל) ---
                if (dataGridView1.Columns.Contains("OrderID"))
                    dataGridView1.Columns["OrderID"].HeaderText = "מספר הזמנה";

                if (dataGridView1.Columns.Contains("userFirstName"))
                    dataGridView1.Columns["userFirstName"].HeaderText = "שם עובד";

                if (dataGridView1.Columns.Contains("game"))
                    dataGridView1.Columns["game"].HeaderText = "שם משחק";

                if (dataGridView1.Columns.Contains("ganre"))
                    dataGridView1.Columns["ganre"].HeaderText = "ז'אנר";

                if (dataGridView1.Columns.Contains("price"))
                    dataGridView1.Columns["price"].HeaderText = "מחיר יחידה";

                if (dataGridView1.Columns.Contains("TypeOfPayment"))
                    dataGridView1.Columns["TypeOfPayment"].HeaderText = "אמצעי תשלום";

                if (dataGridView1.Columns.Contains("Date"))
                    dataGridView1.Columns["Date"].HeaderText = "תאריך";

                if (dataGridView1.Columns.Contains("Amount"))
                    dataGridView1.Columns["Amount"].HeaderText = "כמות";

                if (dataGridView1.Columns.Contains("total"))
                    dataGridView1.Columns["total"].HeaderText = "סה\"כ";
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת נתוני הקבלה: " + ex.Message);
            }
        }

        private void receipt_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
