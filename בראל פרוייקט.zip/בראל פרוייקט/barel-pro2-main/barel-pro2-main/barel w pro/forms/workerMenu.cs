﻿using System;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class workerMenu : Form
    {
        private int workerId = 0;
        private string workerName = string.Empty;

        public workerMenu()
        {
            InitializeComponent();
            UpdateWorkerNameLabel();
        }

        public workerMenu(int id) : this()
        {
            this.workerId = id;
            UpdateWorkerNameLabel();
        }

        public workerMenu(int id, string name) : this(id)
        {
            this.workerName = name ?? string.Empty;
            UpdateWorkerNameLabel();
        }

        private void UpdateWorkerNameLabel()
        {
            if (label2 == null) return;

            if (!string.IsNullOrWhiteSpace(workerName))
                label2.Text = workerName;
            else if (workerId > 0)
                label2.Text = workerId.ToString();
            else
                label2.Text = string.Empty;
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            try
            {
                if (workerId > 0)
                {
                    new PurchaseHistoryReport(workerId, true).Show();
                }
                else
                {
                    new PurchaseHistoryReport().Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בפתיחת נתוני המכירות:\n" + ex.Message);
            }
        }

        private void btnPurchases_Click(object sender, EventArgs e)
        {
            new buyFromSupplierForm().Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            if (Application.OpenForms["login"] != null)
                Application.OpenForms["login"].Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                new Games().Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בפתיחת טופס המשחקים:\n" + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { new customerStore().Show(); } catch { MessageBox.Show("טופס מכירה לא נמצא"); }
        }
    }
}