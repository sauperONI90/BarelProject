﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class PurchaseHistoryReport : Form
    {
        private enum ReportScope
        {
            All,
            Worker,
            Customer
        }

        private readonly int actorId = 0;
        private readonly ReportScope scope = ReportScope.All;
        private bool sortByCommission = false;

        public PurchaseHistoryReport()
        {
            InitializeComponent();

            this.Load += PurchaseHistoryReport_Load;
            if (button1 != null)
            {
                button1.Click += button1_Click;
            }
            if (button2 != null)
            {
                button2.Click += button2_Click;
            }

            if (listView1 != null)
            {
                listView1.View = View.Details;
                listView1.GridLines = true;
                listView1.FullRowSelect = true;
                listView1.RightToLeft = RightToLeft.Yes;
                listView1.RightToLeftLayout = true;
            }

            ApplyRoleBasedControls();
        }

        public PurchaseHistoryReport(int actorId, bool isWorkerView) : this()
        {
            this.actorId = actorId;
            this.scope = isWorkerView ? ReportScope.Worker : ReportScope.Customer;
            ApplyRoleBasedControls();
        }

        private void PurchaseHistoryReport_Load(object sender, EventArgs e)
        {
            LoadSalesData("");
        }

        private void ApplyRoleBasedControls()
        {
            if (button2 != null)
            {
                button2.Visible = scope == ReportScope.All;
            }

            if (label2 != null)
            {
                label2.Visible = scope == ReportScope.Worker;
            }
        }

        private void LoadSalesData(string filterOrderId)
        {
            if (listView1 == null) return;

            listView1.Items.Clear();
            listView1.Columns.Clear();

            string connectionString = DbMain.ConnectionString;

            try
            {
                using (System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection(connectionString))
                {
                    string sql = @"SELECT * FROM WORKERSALESQ";

                    using (System.Data.OleDb.OleDbCommand cmd = new System.Data.OleDb.OleDbCommand(sql, conn))
                    using (System.Data.OleDb.OleDbDataAdapter da = new System.Data.OleDb.OleDbDataAdapter(cmd))
                    {
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                        {
                            UpdateWorkerCommissionLabel(null, null);

                            if (!string.IsNullOrWhiteSpace(filterOrderId))
                            {
                                MessageBox.Show("לא נמצאה הזמנה עם מספר זה.");
                            }
                            return;
                        }

                        DataTable dt = ds.Tables[0];
                        string filterStr = BuildFilterString(dt, filterOrderId);
                        string sortExpression = BuildSortExpression(dt);

                        DataRow[] rowsToDisplay;
                        if (string.IsNullOrWhiteSpace(sortExpression))
                        {
                            rowsToDisplay = string.IsNullOrWhiteSpace(filterStr)
                                ? dt.Select()
                                : dt.Select(filterStr);
                        }
                        else
                        {
                            rowsToDisplay = string.IsNullOrWhiteSpace(filterStr)
                                ? dt.Select(null, sortExpression)
                                : dt.Select(filterStr, sortExpression);
                        }

                        UpdateWorkerCommissionLabel(rowsToDisplay, dt);

                        if (rowsToDisplay.Length == 0)
                        {
                            MessageBox.Show("לא נמצאו תוצאות לחיפוש זה.");
                            return;
                        }

                        foreach (DataColumn column in dt.Columns)
                        {
                            string headerText = column.ColumnName;

                            switch (column.ColumnName)
                            {
                                case "OrderID": headerText = "מספר הזמנה"; break;
                                case "customerID": headerText = "ת.ז. לקוח"; break;
                                case "userFirstName": headerText = "שם עובד"; break;
                                case "game": headerText = "שם משחק"; break;
                                case "ganre": headerText = "ז'אנר"; break;
                                case "price": headerText = "מחיר"; break;
                                case "TypeOfPayment": headerText = "תשלום"; break;
                                case "CardNum": headerText = "מספר כרטיס"; break;
                                case "CVV": headerText = "CVV"; break;
                                case "Date": headerText = "תאריך"; break;
                                case "Amount": headerText = "כמות"; break;
                                case "total": headerText = "סה\"כ"; break;
                                case "Commission": headerText = "עמלה שנצברה"; break;
                            }

                            if (column.ColumnName == "ID")
                                continue;

                            listView1.Columns.Add(column.ColumnName, headerText, 100);
                        }

                        foreach (DataRow row in rowsToDisplay)
                        {
                            ListViewItem item = null;

                            foreach (ColumnHeader col in listView1.Columns)
                            {
                                string cellValue = "";

                                if (col.Name == "Date" && row["Date"] != DBNull.Value)
                                {
                                    cellValue = Convert.ToDateTime(row["Date"]).ToString("dd/MM/yyyy HH:mm");
                                }
                                else
                                {
                                    cellValue = row[col.Name] != DBNull.Value ? row[col.Name].ToString() : "";
                                }

                                if (item == null)
                                {
                                    item = new ListViewItem(cellValue);
                                }
                                else
                                {
                                    item.SubItems.Add(cellValue);
                                }
                            }

                            if (item != null)
                            {
                                listView1.Items.Add(item);
                            }
                        }

                        foreach (ColumnHeader col in listView1.Columns)
                        {
                            col.Width = -2;
                        }
                    }
                }
            }
            catch (System.Data.OleDb.OleDbException dbEx)
            {
                MessageBox.Show($"שגיאת בסיס נתונים. כנראה שלשאילתה {dbEx.Message} חסר פרמטר מובנה מאקסס.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת היסטוריית רכישות מהשאילתה:\n\n" + ex.Message, "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateWorkerCommissionLabel(DataRow[] rowsToDisplay, DataTable dt)
        {
            if (label2 == null)
                return;

            if (scope != ReportScope.Worker || actorId <= 0)
            {
                label2.Visible = false;
                return;
            }

            label2.Visible = true;

            decimal monthlyCommission = 0m;
            DateTime now = DateTime.Now;

            if (dt != null && rowsToDisplay != null)
            {
                string commissionColumn = ResolveColumnName(dt, "Commission", "עמלה");
                string dateColumn = ResolveColumnName(dt, "Date", "תאריך");

                if (!string.IsNullOrWhiteSpace(commissionColumn) && !string.IsNullOrWhiteSpace(dateColumn))
                {
                    List<KeyValuePair<DateTime, decimal>> parsedRows = new List<KeyValuePair<DateTime, decimal>>();

                    foreach (DataRow row in rowsToDisplay)
                    {
                        if (row[dateColumn] == DBNull.Value || row[commissionColumn] == DBNull.Value)
                            continue;

                        DateTime saleDate;
                        if (!TryParseSaleDate(row[dateColumn].ToString(), out saleDate))
                            continue;

                        decimal commissionValue;
                        string commissionText = row[commissionColumn].ToString().Trim();
                        if (!(decimal.TryParse(commissionText, NumberStyles.Any, CultureInfo.CurrentCulture, out commissionValue) ||
                              decimal.TryParse(commissionText, NumberStyles.Any, CultureInfo.InvariantCulture, out commissionValue)))
                        {
                            continue;
                        }

                        parsedRows.Add(new KeyValuePair<DateTime, decimal>(saleDate, commissionValue));
                    }

                    foreach (KeyValuePair<DateTime, decimal> entry in parsedRows)
                    {
                        if (entry.Key.Year == now.Year && entry.Key.Month == now.Month)
                        {
                            monthlyCommission += entry.Value;
                        }
                    }

                    if (monthlyCommission == 0m && parsedRows.Count > 0)
                    {
                        DateTime latest = parsedRows[0].Key;
                        for (int i = 1; i < parsedRows.Count; i++)
                        {
                            if (parsedRows[i].Key > latest)
                                latest = parsedRows[i].Key;
                        }

                        foreach (KeyValuePair<DateTime, decimal> entry in parsedRows)
                        {
                            if (entry.Key.Year == latest.Year && entry.Key.Month == latest.Month)
                            {
                                monthlyCommission += entry.Value;
                            }
                        }
                    }
                }
            }

            label2.Text = $"עמלה בחודש הנוכחי: {monthlyCommission:0.##} ₪";
        }

        private string ResolveColumnName(DataTable dt, params string[] candidates)
        {
            foreach (string candidate in candidates)
            {
                foreach (DataColumn col in dt.Columns)
                {
                    if (string.Equals(col.ColumnName, candidate, StringComparison.OrdinalIgnoreCase))
                        return col.ColumnName;
                }
            }

            foreach (string candidate in candidates)
            {
                foreach (DataColumn col in dt.Columns)
                {
                    if (col.ColumnName.IndexOf(candidate, StringComparison.OrdinalIgnoreCase) >= 0)
                        return col.ColumnName;
                }
            }

            return null;
        }

        private bool TryParseSaleDate(string dateText, out DateTime saleDate)
        {
            if (DateTime.TryParse(dateText, CultureInfo.CurrentCulture, DateTimeStyles.None, out saleDate))
                return true;

            if (DateTime.TryParse(dateText, CultureInfo.InvariantCulture, DateTimeStyles.None, out saleDate))
                return true;

            string[] formats = { "HH:mm dd/MM/yyyy", "H:mm dd/MM/yyyy", "dd/MM/yyyy HH:mm", "dd/MM/yyyy H:mm", "dd/MM/yyyy" };
            return DateTime.TryParseExact(dateText, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out saleDate)
                   || DateTime.TryParseExact(dateText, formats, CultureInfo.GetCultureInfo("he-IL"), DateTimeStyles.None, out saleDate);
        }

        private bool IsWorkerRow(DataRow row, DataTable dt, string workerName)
        {
            if (dt.Columns.Contains("workerID") && row["workerID"].ToString() == actorId.ToString()) return true;
            if (dt.Columns.Contains("WorkerID") && row["WorkerID"].ToString() == actorId.ToString()) return true;
            if (dt.Columns.Contains("userID") && row["userID"].ToString() == actorId.ToString()) return true;
            if (dt.Columns.Contains("userId") && row["userId"].ToString() == actorId.ToString()) return true;
            if (dt.Columns.Contains("UserID") && row["UserID"].ToString() == actorId.ToString()) return true;
            if (dt.Columns.Contains("UserId") && row["UserId"].ToString() == actorId.ToString()) return true;

            if (!string.IsNullOrWhiteSpace(workerName))
            {
                if (dt.Columns.Contains("userFirstName") && string.Equals(row["userFirstName"].ToString().Trim(), workerName, StringComparison.OrdinalIgnoreCase)) return true;
                if (dt.Columns.Contains("UserFirstName") && string.Equals(row["UserFirstName"].ToString().Trim(), workerName, StringComparison.OrdinalIgnoreCase)) return true;
                if (dt.Columns.Contains("workerName") && string.Equals(row["workerName"].ToString().Trim(), workerName, StringComparison.OrdinalIgnoreCase)) return true;
                if (dt.Columns.Contains("WorkerName") && string.Equals(row["WorkerName"].ToString().Trim(), workerName, StringComparison.OrdinalIgnoreCase)) return true;
            }

            return false;
        }

        private string GetWorkerFirstNameById(int workerId)
        {
            try
            {
                DataSet ds = DbMain.ReturnDS($"SELECT userFirstName FROM users WHERE userId = {workerId}");
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    return ds.Tables[0].Rows[0]["userFirstName"]?.ToString().Trim();
                }
            }
            catch
            {
            }

            return "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1 != null && !string.IsNullOrWhiteSpace(textBox1.Text))
            {
                if (!int.TryParse(textBox1.Text.Trim(), out _))
                {
                    MessageBox.Show("אנא הכנס מספר הזמנה תקין לחיפוש.");
                    return;
                }

                LoadSalesData(textBox1.Text.Trim());
            }
            else
            {
                LoadSalesData("");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (scope != ReportScope.All)
                return;

            sortByCommission = true;
            LoadSalesData("");
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            if (textBox1 != null) textBox1.Text = "";
            LoadSalesData("");
        }

        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void PurchaseHistoryReport_Load_1(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private string BuildSortExpression(DataTable dt)
        {
            if (sortByCommission && dt.Columns.Contains("Commission"))
            {
                if (dt.Columns.Contains("OrderID"))
                    return "Commission DESC, OrderID DESC";

                return "Commission DESC";
            }

            if (dt.Columns.Contains("OrderID"))
                return "OrderID DESC";

            return "";
        }

        private string BuildFilterString(DataTable dt, string filterOrderId)
        {
            string filterStr = "";

            if (!string.IsNullOrWhiteSpace(filterOrderId))
            {
                filterStr = $"OrderID = {filterOrderId}";
            }

            string roleFilter = BuildRoleFilter(dt);
            if (!string.IsNullOrWhiteSpace(roleFilter))
            {
                filterStr = string.IsNullOrWhiteSpace(filterStr)
                    ? roleFilter
                    : $"{filterStr} AND {roleFilter}";
            }

            return filterStr;
        }

        private string BuildRoleFilter(DataTable dt)
        {
            if (scope == ReportScope.All || actorId <= 0)
                return "";

            if (scope == ReportScope.Customer)
            {
                if (dt.Columns.Contains("customerID")) return $"customerID = {actorId}";
                if (dt.Columns.Contains("costumerID")) return $"costumerID = {actorId}";
                if (dt.Columns.Contains("CustomerID")) return $"CustomerID = {actorId}";
                if (dt.Columns.Contains("CostumerID")) return $"CostumerID = {actorId}";

                MessageBox.Show("לא נמצאה עמודת לקוח בדוח ולכן לא ניתן להציג היסטוריה מסוננת.");
                return "1 = 0";
            }

            if (scope == ReportScope.Worker)
            {
                if (dt.Columns.Contains("workerID")) return $"workerID = {actorId}";
                if (dt.Columns.Contains("WorkerID")) return $"WorkerID = {actorId}";
                if (dt.Columns.Contains("userID")) return $"userID = {actorId}";
                if (dt.Columns.Contains("userId")) return $"userId = {actorId}";
                if (dt.Columns.Contains("UserID")) return $"UserID = {actorId}";
                if (dt.Columns.Contains("UserId")) return $"UserId = {actorId}";

                string workerName = GetWorkerFirstNameById(actorId);
                if (!string.IsNullOrWhiteSpace(workerName))
                {
                    string safeName = workerName.Replace("'", "''");

                    if (dt.Columns.Contains("userFirstName")) return $"userFirstName = '{safeName}'";
                    if (dt.Columns.Contains("UserFirstName")) return $"UserFirstName = '{safeName}'";
                    if (dt.Columns.Contains("workerName")) return $"workerName = '{safeName}'";
                    if (dt.Columns.Contains("WorkerName")) return $"WorkerName = '{safeName}'";
                }

                MessageBox.Show("לא נמצאה עמודת עובד בדוח ולכן לא ניתן להציג היסטוריה מסוננת.");
                return "1 = 0";
            }

            return "";
        }
    }
}
