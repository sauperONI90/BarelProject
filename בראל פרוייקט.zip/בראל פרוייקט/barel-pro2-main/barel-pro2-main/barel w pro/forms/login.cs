﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using barel_w_pro.appclass;
using System.Text;
using System.Globalization;
using System.Linq;
using System.Diagnostics;

namespace barel_w_pro.forms
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();

            // ensure numeric textbox behaves as expected:
            try
            {
                // disable IME for the ID textbox so Hebrew layout won't insert letters like 'ט'
                txtID.ImeMode = ImeMode.Disable;

                // wire events in case Designer didn't
                txtID.Enter += txtID_Enter;
                txtID.KeyPress += txtID_KeyPress;
                txtID.TextChanged += txtID_TextChanged;
            }
            catch { /* harmless if controls not yet ready in Designer */ }
        }

        private void login_Load(object sender, EventArgs e)
        {
            lblFullDateTime.Text = DateTime.Now.ToString("HH:mm  |  dd/MM/yyyy");
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("נא למלא את כל השדות");
                    return;
                }

                string idText = txtID.Text.Trim();
                if (!int.TryParse(idText, out int userId))
                {
                    MessageBox.Show("תעודת זהות חייבת להיות מספר.");
                    return;
                }

                string userFirstName = txtFirstName.Text.Trim();
                string userFirstNameClean = Clean(userFirstName);
                string role = null;
                string name = null;

                // Query users by id only (more robust than relying on exact column names for name)
                string sqlUsers = $"SELECT * FROM [users] WHERE [userId] = {userId}";
                DataSet dsUsers = null;
                try
                {
                    dsUsers = DbMain.ReturnDS(sqlUsers);
                }
                catch (System.Data.OleDb.OleDbException odex)
                {
                    Debug.WriteLine($"DB error in users query: {sqlUsers}\n{odex}");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"DB error in users query: {sqlUsers}\n{ex}");
                }

                if (dsUsers != null && dsUsers.Tables.Count > 0 && dsUsers.Tables[0].Rows.Count > 0)
                {
                    // pick first matching row and find role/name columns tolerant to naming differences
                    var userRow = dsUsers.Tables[0].Rows[0];

                    // find name column
                    string nameCol = null;
                    foreach (DataColumn c in userRow.Table.Columns)
                    {
                        var n = c.ColumnName.ToLower();
                        if (n.Contains("first") || n.Contains("name"))
                        {
                            nameCol = c.ColumnName;
                            break;
                        }
                    }
                    if (nameCol == null)
                    {
                        // fallback to first string column
                        nameCol = userRow.Table.Columns.Cast<DataColumn>().FirstOrDefault(c => c.DataType == typeof(string))?.ColumnName;
                    }

                    // find role column
                    string roleCol = null;
                    foreach (DataColumn c in userRow.Table.Columns)
                    {
                        var n = c.ColumnName.ToLower();
                        if (n.Contains("role"))
                        {
                            roleCol = c.ColumnName;
                            break;
                        }
                    }

                    name = nameCol != null ? userRow[nameCol].ToString() : "(ללא שם)";
                    role = roleCol != null ? userRow[roleCol].ToString() : "לקוח"; // assume customer if role missing
                }
                else
                {
                    // Try customer table - first attempt with costumerId
                    string sqlCustomer = $"SELECT * FROM [customer] WHERE [costumerId] = {userId}";
                    DataSet dsCustomer = null;
                    
                    try
                    {
                        dsCustomer = DbMain.ReturnDS(sqlCustomer);
                    }
                    catch
                    {
                        // If costumerId failed, try customerId
                        try
                        {
                            sqlCustomer = $"SELECT * FROM [customer] WHERE [customerId] = {userId}";
                            dsCustomer = DbMain.ReturnDS(sqlCustomer);
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"DB error in customer query: {sqlCustomer}\n{ex}");
                            MessageBox.Show("שגיאת בסיס נתונים בעת חיפוש לקוח.");
                            return;
                        }
                    }

                    if (dsCustomer != null && dsCustomer.Tables.Count > 0 && dsCustomer.Tables[0].Rows.Count > 0)
                    {
                        var row = dsCustomer.Tables[0].Rows[0];

                        // find a candidate first-name column - prioritize "first" before general "name"
                        string dbFirstName = null;
                        
                        // Try exact column names first
                        if (row.Table.Columns.Contains("costumerFirstname"))
                            dbFirstName = row["costumerFirstname"].ToString().Trim();
                        else if (row.Table.Columns.Contains("customerFirstname"))
                            dbFirstName = row["customerFirstname"].ToString().Trim();
                        else if (row.Table.Columns.Contains("customerFirstName"))
                            dbFirstName = row["customerFirstName"].ToString().Trim();
                        else if (row.Table.Columns.Contains("costumerFirstName"))
                            dbFirstName = row["costumerFirstName"].ToString().Trim();
                        
                        // Dynamic search if exact names didn't work
                        if (string.IsNullOrEmpty(dbFirstName))
                        {
                            foreach (DataColumn col in row.Table.Columns)
                            {
                                var colNameLower = col.ColumnName.ToLower();
                                if (colNameLower.Contains("first"))
                                {
                                    dbFirstName = row[col].ToString().Trim();
                                    if (!string.IsNullOrEmpty(dbFirstName))
                                        break;
                                }
                            }
                        }

                        if (!string.IsNullOrEmpty(dbFirstName))
                        {
                            string dbFirstNameClean = Clean(dbFirstName);
                            if (dbFirstNameClean.Equals(userFirstNameClean, StringComparison.OrdinalIgnoreCase))
                            {
                                role = "לקוח";
                                name = dbFirstName;
                            }
                            else
                            {
                                MessageBox.Show($"תעודת זהות {userId} נמצאה במערכת אך השם שהוזן ('{userFirstName}') לא תואם לשם הרשום ('{dbFirstName}').");
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show($"נמצא לקוח עם ת.ז {userId} אך לא נמצאה שדה שם להתאמה.");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show($"פרטי התחברות שגויים.\n\nלא נמצא משתמש בשם '{userFirstName}' עם ת.ז {userId}.");
                        return;
                    }
                }

                if (role != null && name != null)
                {
                    MessageBox.Show($"שלום {name}, זוהית כ-{role}. מעביר אותך...");

                    if (role == "מנהל")
                    {
                        new adminMenu().Show();
                    }
                    else if (role == "עובד")
                    {
                        // העברת מזהה ושם העובד ל-workerMenu
                        new workerMenu(userId, name).Show();
                    }
                    else if (role == "לקוח")
                    {
                        new CostumerMenu(userId).Show();
                    }
                    else
                    {
                        MessageBox.Show($"תפקיד '{role}' אינו מוגדר במערכת.");
                        return;
                    }

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("שגיאה בזיהוי המשתמש.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה במערכת:\n" + ex.Message);
            }
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allow control keys and digits only
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        // ensure pasted text is sanitized (only digits kept)
        private void txtID_TextChanged(object sender, EventArgs e)
        {
            try
            {
                var digits = new string(txtID.Text.Where(char.IsDigit).ToArray());
                if (txtID.Text != digits)
                {
                    int sel = txtID.SelectionStart;
                    txtID.Text = digits;
                    txtID.SelectionStart = Math.Min(sel, txtID.Text.Length);
                }
            }
            catch { }
        }

        // when entering the textbox prefer English input and disable IME
        private void txtID_Enter(object sender, EventArgs e)
        {
            try
            {
                txtID.ImeMode = ImeMode.Disable;
                foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
                {
                    if (lang.Culture != null && lang.Culture.TwoLetterISOLanguageName == "en")
                    {
                        InputLanguage.CurrentInputLanguage = lang;
                        break;
                    }
                }
            }
            catch { }
        }

        // עזר לנרמול והסרת תווים בלתי מדפיסים
        private static string Clean(string s)
        {
            if (s == null) return string.Empty;
            var sb = new StringBuilder();
            foreach (char c in s.Normalize(NormalizationForm.FormC))
            {
                if (!char.IsControl(c) && (!char.IsWhiteSpace(c) || c == ' '))
                    sb.Append(c);
            }
            return sb.ToString().Trim();
        }

        private void txtFirstName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}