﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class CostumerMenu : Form
    {
        private int initialCustomerId = 0;

        public CostumerMenu()
        {
            InitializeComponent();

            if (this.Controls.Find("button1", true).FirstOrDefault() is Button b1)
                b1.Click += (s, e) => TryOpen("customerStore", () => new customerStore(initialCustomerId));

            // כפתור 2 מוביל לטופס הקטלוג
            if (this.Controls.Find("button2", true).FirstOrDefault() is Button b2)
                b2.Click += (s, e) => TryOpen("catalouge", () => new catalouge());

            // כאן קישרנו את כפתור 3 לטופס דוח היסטוריית הרכישות שיצרנו הרגע
            if (this.Controls.Find("button3", true).FirstOrDefault() is Button b3)
                b3.Click += (s, e) => TryOpen("PurchaseHistoryReport", () => new PurchaseHistoryReport(initialCustomerId, false));

            if (this.Controls.Find("btnLogout", true).FirstOrDefault() is Button logout)
                logout.Click += (s, e) =>
                {
                    this.Close();
                    if (Application.OpenForms["login"] != null)
                        Application.OpenForms["login"].Show();
                };
        }

        // Overload so caller (login) can pass customer id to the menu
        public CostumerMenu(int customerId) : this()
        {
            initialCustomerId = customerId;
        }

        // Try to bring an already-open form to front, otherwise create and show it.
        private void TryOpen(string formNameOrType, Func<Form> createForm)
        {
            try
            {
                // Try lookup by form Name key first
                Form open = Application.OpenForms[formNameOrType];

                // If not found by , try by type name
                if (open == null)
                    open = Application.OpenForms.Cast<Form>()
                        .FirstOrDefault(f => string.Equals(f.GetType().Name, formNameOrType, StringComparison.OrdinalIgnoreCase));

                if (open != null)
                {
                    open.Show();
                    if (open.WindowState == FormWindowState.Minimized)
                        open.WindowState = FormWindowState.Normal;
                    open.BringToFront();
                }
                else
                {
                    var f = createForm();
                    f.Show();
                }

                // בעת פתיחת חלון חדש אנו ממזערים/מסתירים את התפריט הראשי
                this.Hide();

                // נוסיף אירוע שכשסוגרים את המסך שפתחתי, התפריט הראשי יחזור להופיע מחדש
                if (open == null) // משמע הטופס רק עכשיו נוצר
                {
                    var createdForm = Application.OpenForms.Cast<Form>().Last();
                    createdForm.FormClosed += (s, e) => this.Show();
                }
                else
                {
                    open.FormClosed += (s, e) => this.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("לא ניתן לפתוח את הטופס: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
