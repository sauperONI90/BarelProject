﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class Supplier : Form
    {
        private readonly string _connString = DbMain.ConnectionString;

        public Supplier() { InitializeComponent(); }

        private void supplierForm1_Load(object sender, EventArgs e)
        {
            LoadData();
            SetNextSupplierId();
        }

        private DataTable QueryTable(string sql, params OleDbParameter[] parameters)
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = new OleDbConnection(_connString))
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
            {
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);

                conn.Open();
                da.Fill(dt);
            }
            return dt;
        }

        private int ExecuteNonQuery(string sql, params OleDbParameter[] parameters)
        {
            using (OleDbConnection conn = new OleDbConnection(_connString))
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);

                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        private void LoadData()
        {
            try
            {
                dgvSuppliers.DataSource = QueryTable("SELECT * FROM supplier ORDER BY supplierID");
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת נתונים: " + ex.Message);
            }
        }

        private void SetNextSupplierId()
        {
            try
            {
                DataTable dt = QueryTable("SELECT MAX(supplierID) AS maxId FROM supplier");
                int nextId = 1;
                if (dt.Rows.Count > 0 && dt.Rows[0]["maxId"] != DBNull.Value)
                    nextId = Convert.ToInt32(dt.Rows[0]["maxId"]) + 1;

                txtSupplierID.Text = nextId.ToString();
            }
            catch
            {
                txtSupplierID.Text = string.Empty;
            }
        }

        private bool TryReadSupplierInputs(out int supplierId, out string companyName, out string contactName, out int phoneNum)
        {
            supplierId = 0;
            phoneNum = 0;
            companyName = txtCompanyName.Text.Trim();
            contactName = txtContactName.Text.Trim();

            if (!int.TryParse(txtSupplierID.Text.Trim(), out supplierId))
            {
                MessageBox.Show("קוד ספק חייב להיות מספר תקין.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(companyName))
            {
                MessageBox.Show("יש להזין שם חברה.");
                return false;
            }

            if (!int.TryParse(txtPhone.Text.Trim(), out phoneNum))
            {
                MessageBox.Show("טלפון חייב להיות מספר בלבד.");
                return false;
            }

            return true;
        }

        private void ClearForNext()
        {
            txtCompanyName.Clear();
            txtContactName.Clear();
            txtPhone.Clear();
            textBox9.Clear();
            SetNextSupplierId();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int supplierId;
                string companyName;
                string contactName;
                int phoneNum;

                if (!TryReadSupplierInputs(out supplierId, out companyName, out contactName, out phoneNum))
                    return;

                int rows = ExecuteNonQuery(
                    "INSERT INTO supplier (supplierID, supplierChainName, supplierContactNum, phoneNUM) VALUES (?, ?, ?, ?)",
                    new OleDbParameter("@supplierID", supplierId),
                    new OleDbParameter("@supplierChainName", companyName),
                    new OleDbParameter("@supplierContactNum", contactName),
                    new OleDbParameter("@phoneNUM", phoneNum));

                if (rows > 0)
                {
                    MessageBox.Show("הספק נוסף בהצלחה!");
                    LoadData();
                    ClearForNext();
                }
                else
                {
                    MessageBox.Show("הוספת הספק נכשלה.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בהוספה: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int supplierId;
                string companyName;
                string contactName;
                int phoneNum;

                if (!TryReadSupplierInputs(out supplierId, out companyName, out contactName, out phoneNum))
                    return;

                int rows = ExecuteNonQuery(
                    "UPDATE supplier SET supplierChainName = ?, supplierContactNum = ?, phoneNUM = ? WHERE supplierID = ?",
                    new OleDbParameter("@supplierChainName", companyName),
                    new OleDbParameter("@supplierContactNum", contactName),
                    new OleDbParameter("@phoneNUM", phoneNum),
                    new OleDbParameter("@supplierID", supplierId));

                if (rows > 0)
                {
                    MessageBox.Show("הספק עודכן בהצלחה!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("לא נמצא ספק לעדכון או שהעדכון נכשל.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בעדכון: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int supplierId;
                if (!int.TryParse(txtSupplierID.Text.Trim(), out supplierId))
                {
                    MessageBox.Show("חובה להזין קוד ספק חוקי למחיקה");
                    return;
                }

                int rows = ExecuteNonQuery(
                    "DELETE FROM supplier WHERE supplierID = ?",
                    new OleDbParameter("@supplierID", supplierId));

                if (rows > 0)
                {
                    MessageBox.Show("הספק נמחק בהצלחה!");
                    LoadData();
                    ClearForNext();
                }
                else
                {
                    MessageBox.Show("לא נמצא ספק למחיקה.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה במחיקה: " + ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBox9.Text))
                {
                    LoadData();
                    return;
                }

                int searchId;
                if (!int.TryParse(textBox9.Text.Trim(), out searchId))
                {
                    MessageBox.Show("יש להזין קוד ספק מספרי לחיפוש.");
                    return;
                }

                DataTable dt = QueryTable("SELECT * FROM supplier WHERE supplierID = ?", new OleDbParameter("@supplierID", searchId));
                dgvSuppliers.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בחיפוש: " + ex.Message);
            }
        }

        private void dgvSuppliers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvSuppliers.Rows[e.RowIndex];

            txtSupplierID.Text = row.Cells["supplierID"].Value?.ToString() ?? "";

            string chainCol = dgvSuppliers.Columns.Contains("supplierChainName")
                ? "supplierChainName"
                : "supplierLastname";
            txtCompanyName.Text = row.Cells[chainCol].Value?.ToString() ?? "";

            string contactCol = dgvSuppliers.Columns.Contains("supplierContactNum")
                ? "supplierContactNum"
                : "supplierContactNun";
            txtContactName.Text = row.Cells[contactCol].Value?.ToString() ?? "";

            txtPhone.Text = row.Cells["phoneNUM"].Value?.ToString() ?? "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }
    }
}