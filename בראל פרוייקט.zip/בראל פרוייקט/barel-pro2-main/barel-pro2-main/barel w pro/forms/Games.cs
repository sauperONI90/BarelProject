﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Windows.Forms;
using barel_w_pro.appclass;

namespace barel_w_pro.forms
{
    public partial class Games : Form
    {
        private string connectionString = DbMain.ConnectionString;

        public Games()
        {
            InitializeComponent();

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.ReadOnly = false;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            textBox6.ReadOnly = true;

            string dbPath = DbMain.DatabasePath;
            if (!System.IO.File.Exists(dbPath))
            {
                MessageBox.Show("קובץ מסד הנתונים לא נמצא בנתיב: " + dbPath,
                    "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.buttonAdd.Click += new EventHandler(buttonAdd_Click);
            this.button4.Click += new EventHandler(button4_Click);
            this.button2.Click += new EventHandler(button2_Click);
            this.button1.Click += new EventHandler(button1_Click);
            this.Shown += new EventHandler(Games_Shown);
        }

        private void Games_Load(object sender, EventArgs e)
        {
            try
            {
                textBox9.Clear();
                LoadSuppliers();
                LoadData();
                SetNextItemId();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת הטופס: " + ex.Message + "\n\n" + ex.StackTrace,
                    "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Games_Shown(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    string sql = "SELECT itemID, gameName, quantity, ganre, supplierID, price FROM GAMES ORDER BY itemID";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView1.DataSource = null;
                    dataGridView1.AutoGenerateColumns = true;
                    dataGridView1.AllowUserToAddRows = false;
                    dataGridView1.DataSource = dt;
                    dataGridView1.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת נתונים: " + ex.Message + "\n\n" +
                    "מיקום: " + ex.StackTrace, "שגיאה",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadSuppliers()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    string sql = "SELECT supplierID, supplierChainName FROM supplier ORDER BY supplierID";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dt.Columns.Add("DisplayText", typeof(string));
                    foreach (DataRow row in dt.Rows)
                    {
                        row["DisplayText"] = row["supplierID"].ToString() + " - " + row["supplierChainName"].ToString();
                    }

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "DisplayText";
                    comboBox1.ValueMember = "supplierID";
                    comboBox1.SelectedIndex = dt.Rows.Count > 0 ? 0 : -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת הספקים: " + ex.Message);
            }
        }

        private void SetNextItemId()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                using (OleDbCommand cmd = new OleDbCommand("SELECT MAX(itemID) FROM GAMES", conn))
                {
                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    int nextItemId = 1;

                    if (result != null && result != DBNull.Value)
                    {
                        nextItemId = Convert.ToInt32(result) + 1;
                    }

                    textBox6.Text = nextItemId.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בקביעת תז פריט הבא: " + ex.Message);
            }
        }

        private int GetSelectedSupplierId()
        {
            if (comboBox1.SelectedValue == null)
            {
                throw new Exception("יש לבחור ספק מהרשימה.");
            }

            return Convert.ToInt32(comboBox1.SelectedValue);
        }

        private bool TryReadGameInputs(out int itemId, out string gameName, out int quantity, out string genre, out int supplierId, out double price)
        {
            itemId = 0;
            quantity = 0;
            supplierId = 0;
            price = 0;
            gameName = textBox8.Text.Trim();
            genre = textBox2.Text.Trim();

            if (!int.TryParse(textBox6.Text.Trim(), out itemId))
            {
                MessageBox.Show("קוד פריט לא תקין.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(gameName))
            {
                MessageBox.Show("יש להזין שם משחק.");
                return false;
            }

            if (!int.TryParse(textBox3.Text.Trim(), out quantity) || quantity < 0)
            {
                MessageBox.Show("כמות חייבת להיות מספר 0 או יותר.");
                return false;
            }

            supplierId = GetSelectedSupplierId();

            string priceText = textBox1.Text.Trim();
            if (!double.TryParse(priceText, NumberStyles.Any, CultureInfo.CurrentCulture, out price) &&
                !double.TryParse(priceText, NumberStyles.Any, CultureInfo.InvariantCulture, out price))
            {
                MessageBox.Show("מחיר לא תקין.");
                return false;
            }

            return true;
        }

        private void ResetFormForNewGame()
        {
            textBox8.Clear();
            textBox3.Clear();
            textBox2.Clear();
            textBox1.Clear();
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
            SetNextItemId();
        }

        private int ExecuteNonQuery(string sql, params OleDbParameter[] parameters)
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);

                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int itemId;
                string gameName;
                int quantity;
                string genre;
                int supplierId;
                double price;

                if (!TryReadGameInputs(out itemId, out gameName, out quantity, out genre, out supplierId, out price))
                    return;

                int rows = ExecuteNonQuery(
                    "INSERT INTO GAMES (itemID, gameName, quantity, ganre, supplierID, price) VALUES (?, ?, ?, ?, ?, ?)",
                    new OleDbParameter("@itemID", itemId),
                    new OleDbParameter("@gameName", gameName),
                    new OleDbParameter("@quantity", quantity),
                    new OleDbParameter("@ganre", genre),
                    new OleDbParameter("@supplierID", supplierId),
                    new OleDbParameter("@price", price));

                if (rows > 0)
                {
                    MessageBox.Show("המשחק נוסף בהצלחה!");
                    LoadData();
                    ResetFormForNewGame();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בהוספת המשחק: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int itemIdForDelete;
                if (!int.TryParse(textBox6.Text.Trim(), out itemIdForDelete))
                {
                    MessageBox.Show("יש לבחור קוד פריט למחיקה.");
                    return;
                }

                int rows = ExecuteNonQuery("DELETE FROM GAMES WHERE itemID = ?", new OleDbParameter("@itemID", itemIdForDelete));
                if (rows > 0)
                {
                    MessageBox.Show("המשחק נמחק בהצלחה!");
                    LoadData();
                    ResetFormForNewGame();
                }
                else
                {
                    MessageBox.Show("לאوجد משחק למחיקה.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה במחיקת המשחק: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox9.Text))
            {
                LoadData();
                SetNextItemId();
                return;
            }

            int searchItemId;
            if (!int.TryParse(textBox9.Text.Trim(), out searchItemId))
            {
                MessageBox.Show("יש להזין קוד פריט מספרי לחיפוש.");
                return;
            }

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    string sql = "SELECT itemID, gameName, quantity, ganre, supplierID, price FROM GAMES WHERE itemID = ?";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(sql, conn);
                    adapter.SelectCommand.Parameters.AddWithValue("?", searchItemId);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                        textBox6.Text = dt.Rows[0]["itemID"].ToString();
                        textBox8.Text = dt.Rows[0]["gameName"].ToString();
                        textBox3.Text = dt.Rows[0]["quantity"].ToString();
                        textBox2.Text = dt.Rows[0]["ganre"].ToString();
                        comboBox1.SelectedValue = Convert.ToInt32(dt.Rows[0]["supplierID"]);
                        textBox1.Text = dt.Rows[0]["price"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("לא נמצא משחק עם המזהה הזה.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("שגיאה בחיפוש הנתונים: " + ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int itemId;
                string gameName;
                int quantity;
                string genre;
                int supplierId;
                double price;

                if (!TryReadGameInputs(out itemId, out gameName, out quantity, out genre, out supplierId, out price))
                    return;

                int rows = ExecuteNonQuery(
                    "UPDATE GAMES SET gameName = ?, quantity = ?, ganre = ?, supplierID = ?, price = ? WHERE itemID = ?",
                    new OleDbParameter("@gameName", gameName),
                    new OleDbParameter("@quantity", quantity),
                    new OleDbParameter("@ganre", genre),
                    new OleDbParameter("@supplierID", supplierId),
                    new OleDbParameter("@price", price),
                    new OleDbParameter("@itemID", itemId));

                if (rows > 0)
                {
                    MessageBox.Show("המשחק עודכן בהצלחה!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("לא נמצא משחק לעדכון.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בעדכון המשחק: " + ex.Message);
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }
    }
}
