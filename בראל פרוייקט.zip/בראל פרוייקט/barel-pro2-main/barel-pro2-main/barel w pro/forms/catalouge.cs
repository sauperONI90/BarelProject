﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class catalouge : Form
    {
        public catalouge()
        {
            InitializeComponent();
            this.Load += catalouge_Load;
        }

        private void catalouge_Load(object sender, EventArgs e)
        {
            try
            {
                listView1.Clear();
                listView1.View = View.Details;
                listView1.FullRowSelect = true;
                listView1.GridLines = true;

                listView1.Columns.Add("קוד משחק", 100, HorizontalAlignment.Center);
                listView1.Columns.Add("שם משחק", 280, HorizontalAlignment.Right);
                listView1.Columns.Add("ז'אנר", 120, HorizontalAlignment.Center);
                listView1.Columns.Add("מזהה ספק", 100, HorizontalAlignment.Center);
                listView1.Columns.Add("מחיר", 100, HorizontalAlignment.Center);
                listView1.Columns.Add("מלאי", 100, HorizontalAlignment.Center);

                string sql = "SELECT itemID, gameName, ganre, supplierID, price, quantity FROM GAMES ORDER BY gameName";
                DataTable dt = DbMain.ReturnDS(sql).Tables[0];

                foreach (DataRow row in dt.Rows)
                {
                    ListViewItem item = new ListViewItem(row["itemID"].ToString());
                    item.SubItems.Add(row["gameName"].ToString());
                    item.SubItems.Add(row["ganre"].ToString());
                    item.SubItems.Add(row["supplierID"].ToString());
                    item.SubItems.Add(row["price"].ToString());
                    item.SubItems.Add(row["quantity"].ToString());
                    listView1.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת קטלוג: " + ex.Message);
            }
        }
    }
}
