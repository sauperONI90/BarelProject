﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class worker : Form
    {
        private readonly string _connString = DbMain.ConnectionString;
        private bool _isInitializing;

        public worker()
        {
            InitializeComponent();
            _isInitializing = true;
            dataGridView1.CellClick += DataGridView1_CellClick;
            LoadUsers();
            dataGridView1.ClearSelection();
            dataGridView1.CurrentCell = null;
            ClearFields();
            _isInitializing = false;
        }

        private bool TryGetUserInput(out int userId, out string firstName, out int phoneNum, out string role)
        {
            userId = 0;
            firstName = textBox8.Text.Trim();
            phoneNum = 0;
            role = textBox2.Text.Trim();

            if (!int.TryParse(textBox6.Text.Trim(), out userId))
            {
                MessageBox.Show("ת.ז עובד חייב להיות מספר תקין");
                return false;
            }

            if (!int.TryParse(textBox3.Text.Trim(), out phoneNum))
            {
                MessageBox.Show("טלפון עובד חייב להיות מספר תקין");
                return false;
            }

            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(role))
            {
                MessageBox.Show("יש למלא שם פרטי ותפקיד");
                return false;
            }

            return true;
        }

        private DataTable GetUsersTable(string sql, params OleDbParameter[] parameters)
        {
            DataTable table = new DataTable();
            using (OleDbConnection conn = new OleDbConnection(_connString))
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }

                conn.Open();
                da.Fill(table);
            }

            return table;
        }

        private int ExecuteNonQuery(string sql, params OleDbParameter[] parameters)
        {
            using (OleDbConnection conn = new OleDbConnection(_connString))
            using (OleDbCommand cmd = new OleDbCommand(sql, conn))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }

                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        private void LoadUsers()
        {
            try
            {
                dataGridView1.DataSource = GetUsersTable("SELECT * FROM users");
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בטעינת עובדים: " + ex.Message);
                dataGridView1.DataSource = null;
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int userId;
                string firstName;
                int phoneNum;
                string role;

                if (!TryGetUserInput(out userId, out firstName, out phoneNum, out role))
                {
                    return;
                }

                int rows = ExecuteNonQuery(
                    "INSERT INTO users (userId, userFirstName, userPhoneNum, userRole) VALUES (?, ?, ?, ?)",
                    new OleDbParameter("@userId", userId),
                    new OleDbParameter("@userFirstName", firstName),
                    new OleDbParameter("@userPhoneNum", phoneNum),
                    new OleDbParameter("@userRole", role));

                if (rows > 0)
                {
                    MessageBox.Show("העובד נוסף בהצלחה");
                    ClearFields();
                    LoadUsers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בהוספת עובד: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int userId;
                if (!int.TryParse(textBox6.Text.Trim(), out userId))
                {
                    MessageBox.Show("יש לבחור עובד למחיקה");
                    return;
                }

                if (MessageBox.Show($"האם למחוק עובד עם ת.ז. {userId}?", "אישור מחיקה", MessageBoxButtons.YesNo) != DialogResult.Yes)
                {
                    return;
                }

                int rows = ExecuteNonQuery(
                    "DELETE FROM users WHERE userId = ?",
                    new OleDbParameter("@userId", userId));

                if (rows > 0)
                {
                    MessageBox.Show("העובד נמחק בהצלחה");
                    ClearFields();
                    LoadUsers();
                }
                else
                {
                    MessageBox.Show("לא נמצא עובד למחיקה");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה במחיקת עובד: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int searchId;
                if (!int.TryParse(textBox9.Text.Trim(), out searchId))
                {
                    MessageBox.Show("יש להכניס ת.ז. מספרית לחיפוש");
                    return;
                }

                DataTable table = GetUsersTable(
                    "SELECT * FROM users WHERE userId = ?",
                    new OleDbParameter("@userId", searchId));

                dataGridView1.DataSource = table;

                if (table.Rows.Count > 0)
                {
                    DataRow row = table.Rows[0];
                    textBox6.Text = row["userId"].ToString();
                    textBox8.Text = row["userFirstName"].ToString();
                    textBox3.Text = row["userPhoneNum"].ToString();
                    textBox2.Text = row["userRole"].ToString();
                }
                else
                {
                    MessageBox.Show("לא נמצא עובד עם ת.ז. זו");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בחיפוש עובד: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int searchId;
                if (!int.TryParse(textBox9.Text.Trim(), out searchId))
                {
                    MessageBox.Show("יש להכניס ת.ז. מספרית לעדכון בשדה החיפוש");
                    return;
                }

                int userId;
                string firstName;
                int phoneNum;
                string role;

                if (!TryGetUserInput(out userId, out firstName, out phoneNum, out role))
                {
                    return;
                }

                int rows = ExecuteNonQuery(
                    "UPDATE users SET userFirstName = ?, userPhoneNum = ?, userRole = ? WHERE userId = ?",
                    new OleDbParameter("@userFirstName", firstName),
                    new OleDbParameter("@userPhoneNum", phoneNum),
                    new OleDbParameter("@userRole", role),
                    new OleDbParameter("@userId", searchId));

                if (rows > 0)
                {
                    MessageBox.Show("העובד עודכן בהצלחה");
                    ClearFields();
                    LoadUsers();
                }
                else
                {
                    MessageBox.Show("לא נמצא עובד עם ת.ז. זו לעדכון");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בעדכון עובד: " + ex.Message);
            }
        }

        private void ClearFields()
        {
            textBox6.Text = "";
            textBox8.Text = "";
            textBox3.Text = "";
            textBox2.Text = "";
            textBox9.Text = "";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (_isInitializing) return;
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            if (row.IsNewRow) return;

            textBox6.Text = row.Cells["userId"].Value?.ToString() ?? "";
            textBox8.Text = row.Cells["userFirstName"].Value?.ToString() ?? "";
            textBox3.Text = row.Cells["userPhoneNum"].Value?.ToString() ?? "";
            textBox2.Text = row.Cells["userRole"].Value?.ToString() ?? "";
        }
    }
}
