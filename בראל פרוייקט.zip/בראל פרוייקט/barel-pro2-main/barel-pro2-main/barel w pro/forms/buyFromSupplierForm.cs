﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class buyFromSupplierForm : Form
    {
        string connString = DbMain.ConnectionString;
        private bool _syncingItemCombos;

        public buyFromSupplierForm()
        {
            InitializeComponent();
            txtBuyID.ReadOnly = true;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            comboBox3.SelectedIndexChanged += comboBox3_SelectedIndexChanged;
            this.Activated += buyFromSupplierForm_Activated;
        }

        private void buyFromSupplierForm_Load(object sender, EventArgs e)
        {
            LoadSupplierCombo();
            ClearItemCombo();
            LoadData();
            SetNextBuyId();
        }

        private void buyFromSupplierForm_Activated(object sender, EventArgs e)
        {
            object selectedSupplier = comboBox1.SelectedValue;

            LoadSupplierCombo();
            LoadData();
            SetNextBuyId();

            if (selectedSupplier != null && !(selectedSupplier is DataRowView))
            {
                int supplierId;
                if (int.TryParse(selectedSupplier.ToString(), out supplierId))
                {
                    comboBox1.SelectedValue = supplierId;
                    LoadItemComboBySupplier(supplierId);
                }
            }
        }

        private int GetNextBuyId(OleDbConnection conn = null)
        {
            bool closeConnection = false;
            OleDbConnection activeConnection = conn;

            if (activeConnection == null)
            {
                activeConnection = new OleDbConnection(connString);
                activeConnection.Open();
                closeConnection = true;
            }

            try
            {
                using (OleDbCommand cmd = new OleDbCommand("SELECT MAX(buyId) FROM buyFromSupplier", activeConnection))
                {
                    object result = cmd.ExecuteScalar();
                    if (result == null || result == DBNull.Value)
                    {
                        return 1;
                    }

                    return Convert.ToInt32(result) + 1;
                }
            }
            finally
            {
                if (closeConnection)
                {
                    activeConnection.Close();
                }
            }
        }

        private void SetNextBuyId()
        {
            try
            {
                txtBuyID.Text = GetNextBuyId().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה ביצירת קוד קנייה אוטומטי: " + ex.Message);
            }
        }

        private void LoadSupplierCombo()
        {
            try
            {
                DataSet ds = DbMain.ReturnDS("SELECT supplierID FROM Supplier ORDER BY supplierID");
                if (ds.Tables.Count == 0)
                {
                    comboBox1.DataSource = null;
                    return;
                }

                comboBox1.DataSource = ds.Tables[0];
                comboBox1.DisplayMember = "supplierID";
                comboBox1.ValueMember = "supplierID";
                comboBox1.SelectedIndex = -1;
            }
            catch (Exception ex) { MessageBox.Show("שגיאה בטעינת ספקים: " + ex.Message); }
        }

        private void ClearItemCombo()
        {
            comboBox2.DataSource = null;
            comboBox2.Items.Clear();
            comboBox2.Text = string.Empty;
            comboBox3.DataSource = null;
            comboBox3.Items.Clear();
            comboBox3.Text = string.Empty;
            comboBox3.SelectedIndex = -1;
        }

        private void LoadItemComboBySupplier(int supplierId)
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    string sql = "SELECT itemID, gameName FROM GAMES WHERE supplierID = ? ORDER BY gameName";
                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("?", supplierId);
                        using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            comboBox2.DataSource = dt;
                            comboBox2.DisplayMember = "gameName";
                            comboBox2.ValueMember = "itemID";
                            comboBox2.SelectedIndex = -1;

                            if (dt.Rows.Count > 0)
                            {
                                DataTable dtItemIDs = dt.DefaultView.ToTable(true, "itemID");
                                dtItemIDs.DefaultView.Sort = "itemID";
                                comboBox3.DataSource = dtItemIDs.DefaultView;
                                comboBox3.DisplayMember = "itemID";
                                comboBox3.ValueMember = "itemID";
                                comboBox3.SelectedIndex = -1;
                            }
                            else
                            {
                                comboBox3.DataSource = null;
                                comboBox3.Items.Clear();
                                comboBox3.SelectedIndex = -1;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("שגיאה בטעינת פריטים: " + ex.Message); }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null || comboBox1.SelectedValue is DataRowView)
            {
                ClearItemCombo();
                return;
            }

            int supplierId;
            if (int.TryParse(comboBox1.SelectedValue.ToString(), out supplierId))
            {
                LoadItemComboBySupplier(supplierId);
            }
            else
            {
                ClearItemCombo();
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_syncingItemCombos) return;

            if (comboBox2.SelectedValue == null || comboBox2.SelectedValue is DataRowView)
            {
                comboBox3.SelectedIndex = -1;
                return;
            }

            _syncingItemCombos = true;
            comboBox3.SelectedValue = comboBox2.SelectedValue;
            _syncingItemCombos = false;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_syncingItemCombos) return;

            if (comboBox3.SelectedValue == null || comboBox3.SelectedValue is DataRowView)
            {
                return;
            }

            _syncingItemCombos = true;
            comboBox2.SelectedValue = comboBox3.SelectedValue;
            _syncingItemCombos = false;
        }

        private void LoadData()
        {
            try
            {
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    string sql = @"SELECT b.buyId,
                                          b.buyDate,
                                          g.supplierID AS supplierId,
                                          b.receiveDate,
                                          g.itemID,
                                          g.gameName,
                                          b.quantity,
                                          g.quantity AS stockQuantity
                                   FROM GAMES AS g
                                   LEFT JOIN buyFromSupplier AS b ON g.itemID = b.itemID
                                   ORDER BY g.itemID, b.buyId";
                    OleDbDataAdapter da = new OleDbDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvPurchases.DataSource = dt;
                }
            }
            catch (Exception ex) { MessageBox.Show("שגיאה בטעינת נתונים: " + ex.Message); }
        }

        private bool TryGetSelectedItemId(out object itemIdParameter, out string itemIdDisplay)
        {
            itemIdParameter = null;
            itemIdDisplay = string.Empty;

            object rawValue = null;

            if (comboBox3.SelectedValue != null && !(comboBox3.SelectedValue is DataRowView))
            {
                rawValue = comboBox3.SelectedValue;
            }
            else if (!string.IsNullOrWhiteSpace(comboBox3.Text))
            {
                rawValue = comboBox3.Text.Trim();
            }
            else if (comboBox2.SelectedValue != null && !(comboBox2.SelectedValue is DataRowView))
            {
                rawValue = comboBox2.SelectedValue;
            }

            if (rawValue == null) return false;

            itemIdDisplay = rawValue.ToString();
            if (string.IsNullOrWhiteSpace(itemIdDisplay)) return false;

            int numericItemId;
            if (int.TryParse(itemIdDisplay, out numericItemId))
                itemIdParameter = numericItemId;
            else
                itemIdParameter = itemIdDisplay;

            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int quantityToAdd;
                if (!int.TryParse(txtQuantity.Text.Trim(), out quantityToAdd) || quantityToAdd <= 0)
                {
                    MessageBox.Show("כמות חייבת להיות מספר חיובי.");
                    return;
                }

                object itemIdParameter;
                string itemIdDisplay;
                if (!TryGetSelectedItemId(out itemIdParameter, out itemIdDisplay))
                {
                    MessageBox.Show("יש לבחור קוד פריט תקין.");
                    return;
                }

                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();

                    int nextBuyId = GetNextBuyId(conn);
                    txtBuyID.Text = nextBuyId.ToString();

                    string checkItemSql = "SELECT COUNT(*) FROM GAMES WHERE itemID = ?";
                    using (OleDbCommand cmdCheck = new OleDbCommand(checkItemSql, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("?", itemIdParameter);
                        int count = Convert.ToInt32(cmdCheck.ExecuteScalar());
                        if (count == 0)
                        {
                            MessageBox.Show("שגיאה: קוד הפריט לא קיים במערכת.\nיש להוסיף את המשחק למערכת (בטבלת GAMES) לפני ביצוע רכש עבורו.");
                            return;
                        }
                    }

                    string sqlInsert = "INSERT INTO buyFromSupplier (buyId, buyDate, supplierId, receiveDate, itemID, quantity) VALUES (?, ?, ?, ?, ?, ?)";
                    using (OleDbCommand cmdInsert = new OleDbCommand(sqlInsert, conn))
                    {
                        cmdInsert.Parameters.AddWithValue("?", nextBuyId);
                        cmdInsert.Parameters.AddWithValue("?", dtpBuyDate.Value.ToShortDateString());
                        cmdInsert.Parameters.AddWithValue("?", comboBox1.SelectedValue);
                        cmdInsert.Parameters.AddWithValue("?", dtpReceiveDate.Value.ToShortDateString());
                        cmdInsert.Parameters.AddWithValue("?", itemIdParameter);
                        cmdInsert.Parameters.AddWithValue("?", quantityToAdd);
                        cmdInsert.ExecuteNonQuery();
                    }

                    string sqlUpdateStock = "UPDATE GAMES SET quantity = Val([quantity] & '') + ? WHERE itemID = ?";
                    using (OleDbCommand cmdUpdate = new OleDbCommand(sqlUpdateStock, conn))
                    {
                        cmdUpdate.Parameters.AddWithValue("?", quantityToAdd);
                        cmdUpdate.Parameters.AddWithValue("?", itemIdParameter);
                        cmdUpdate.ExecuteNonQuery();
                    }

                    MessageBox.Show("הקנייה נוספה והמלאי עודכן בהצלחה!");
                    LoadData();
                    SetNextBuyId();
                }
            }
            catch (Exception ex) { MessageBox.Show("שגיאה בהוספה: " + ex.Message); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtQuantity.Text))
            {
                MessageBox.Show("יש לבחור פריט וכמות תחילה.");
                return;
            }

            int quantityToAdd;
            if (!int.TryParse(txtQuantity.Text.Trim(), out quantityToAdd) || quantityToAdd <= 0)
            {
                MessageBox.Show("כמות חייבת להיות מספר חיובי.");
                return;
            }

            object itemIdParameter;
            string itemIdDisplay;
            if (!TryGetSelectedItemId(out itemIdParameter, out itemIdDisplay))
            {
                MessageBox.Show("יש לבחור קוד פריט תקין.");
                return;
            }

            try
            {
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();

                    string sqlUpdate = "UPDATE GAMES SET quantity = Val([quantity] & '') + ? WHERE itemID = ?";
                    using (OleDbCommand cmd = new OleDbCommand(sqlUpdate, conn))
                    {
                        cmd.Parameters.AddWithValue("?", quantityToAdd);
                        cmd.Parameters.AddWithValue("?", itemIdParameter);
                        int rows = cmd.ExecuteNonQuery();

                        if (rows == 0)
                        {
                            MessageBox.Show($"לא נמצא משחק עם קוד פריט {itemIdDisplay} בטבלת GAMES.");
                            return;
                        }
                    }

                    MessageBox.Show($"המלאי עודכן בהצלחה! נוספו {quantityToAdd} יחידות.");
                    LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאה בעדכון מלאי: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBuyID.Text))
            {
                MessageBox.Show("לא נבחרה רשומת קנייה למחיקה.");
                return;
            }

            if (MessageBox.Show("למחוק קנייה זו?", "אישור", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    using (OleDbConnection conn = new OleDbConnection(connString))
                    {
                        conn.Open();
                        string sql = "DELETE FROM buyFromSupplier WHERE buyId=?";
                        OleDbCommand cmd = new OleDbCommand(sql, conn);
                        cmd.Parameters.AddWithValue("?", txtBuyID.Text);
                        cmd.ExecuteNonQuery();
                        LoadData();
                        SetNextBuyId();
                        MessageBox.Show("נמחק!");
                    }
                }
                catch (Exception ex) { MessageBox.Show("שגיאה במחיקה: " + ex.Message); }
            }
        }

        private bool TrySelectComboValue(ComboBox combo, object value)
        {
            if (combo == null || value == null || value == DBNull.Value) return false;

            string target = value.ToString();
            if (string.IsNullOrWhiteSpace(target)) return false;

            if (!string.IsNullOrWhiteSpace(combo.ValueMember))
            {
                foreach (object item in combo.Items)
                {
                    DataRowView drv = item as DataRowView;
                    if (drv != null)
                    {
                        object memberValue = drv[combo.ValueMember];
                        if (memberValue != null && memberValue != DBNull.Value &&
                            string.Equals(memberValue.ToString(), target, StringComparison.OrdinalIgnoreCase))
                        {
                            combo.SelectedItem = item;
                            return true;
                        }
                    }
                }
            }

            for (int i = 0; i < combo.Items.Count; i++)
            {
                object item = combo.Items[i];
                if (item != null && string.Equals(item.ToString(), target, StringComparison.OrdinalIgnoreCase))
                {
                    combo.SelectedIndex = i;
                    return true;
                }
            }

            return false;
        }

        private void dgvPurchases_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvPurchases.Rows[e.RowIndex];

            txtBuyID.Text = row.Cells["buyId"].Value?.ToString() ?? string.Empty;
            txtQuantity.Text = row.Cells["quantity"].Value?.ToString() ?? string.Empty;

            object supplierValue = row.Cells["supplierId"].Value;
            int supplierId;
            if (supplierValue != null && supplierValue != DBNull.Value && int.TryParse(supplierValue.ToString(), out supplierId))
            {
                comboBox1.SelectedValue = supplierId;
                LoadItemComboBySupplier(supplierId);
            }

            object itemValue = row.Cells["itemID"].Value;
            string itemText = itemValue == null || itemValue == DBNull.Value ? string.Empty : itemValue.ToString();
            string gameNameText = string.Empty;
            if (dgvPurchases.Columns.Contains("gameName"))
            {
                object gameNameValue = row.Cells["gameName"].Value;
                if (gameNameValue != null && gameNameValue != DBNull.Value)
                    gameNameText = gameNameValue.ToString();
            }

            bool itemCodeSelected = TrySelectComboValue(comboBox3, itemValue);
            bool itemNameSelected = TrySelectComboValue(comboBox2, itemValue);

            if (!itemCodeSelected)
            {
                comboBox3.Text = itemText;
            }

            if (!itemNameSelected)
            {
                if (!string.IsNullOrWhiteSpace(gameNameText))
                    comboBox2.Text = gameNameText;
                else
                    comboBox2.Text = itemText;
            }

            object buyDateValue = row.Cells["buyDate"].Value;
            if (buyDateValue != null && buyDateValue != DBNull.Value)
            {
                DateTime buyDate;
                if (DateTime.TryParse(buyDateValue.ToString(), CultureInfo.CurrentCulture, DateTimeStyles.None, out buyDate))
                {
                    dtpBuyDate.Value = buyDate;
                }
            }

            object receiveDateValue = row.Cells["receiveDate"].Value;
            if (receiveDateValue != null && receiveDateValue != DBNull.Value)
            {
                DateTime receiveDate;
                if (DateTime.TryParse(receiveDateValue.ToString(), CultureInfo.CurrentCulture, DateTimeStyles.None, out receiveDate))
                {
                    dtpReceiveDate.Value = receiveDate;
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
