﻿using System;
using System.Data;
using System.Windows.Forms;

namespace barel_w_pro.forms
{
    public partial class InventoryReport : Form
    {
        public InventoryReport()
        {
            InitializeComponent();
        }

        private void InventoryReport_Load(object sender, EventArgs e)
        {
            try
            {
                listView1.Clear();
                listView1.View = View.Details;
                listView1.FullRowSelect = true;
                listView1.GridLines = true;

                listView1.Columns.Add("קוד משחק", 120, HorizontalAlignment.Center);
                listView1.Columns.Add("שם משחק", 450, HorizontalAlignment.Right);
                listView1.Columns.Add("מלאי", 120, HorizontalAlignment.Center);

                string sql = "SELECT itemID, gameName, quantity FROM GAMES ORDER BY gameName";
                DataTable dt = DbMain.ReturnDS(sql).Tables[0];

                foreach (DataRow row in dt.Rows)
                {
                    ListViewItem item = new ListViewItem(row["itemID"].ToString());
                    item.SubItems.Add(row["gameName"].ToString());
                    item.SubItems.Add(row["quantity"].ToString());
                    listView1.Items.Add(item);
                }
            }
            catch (Exception ex) { MessageBox.Show("שגיאה: " + ex.Message); }
        }
    }
}