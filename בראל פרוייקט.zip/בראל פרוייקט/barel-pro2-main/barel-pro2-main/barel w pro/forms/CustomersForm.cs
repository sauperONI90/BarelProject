﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace barel_w_pro
{
    public partial class CustomersForm : Form
    {
        public CustomersForm()
        {
            InitializeComponent();
        }

        public static bool emailIsValid(string email)
        {
            string expresion;
            expresion = "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
            if (Regex.IsMatch(email, expresion))
            {
                if (Regex.Replace(email, expresion, string.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        private void CustomersForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = DbMain.GetAllRecord("customer").Tables[0];
        }

        // כפתור חפש - חיפוש לקוח לפי מספר ת.ז
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox9.Text == "")
            {
                MessageBox.Show("נא להזין מספר לקוח לחיפוש");
                return;
            }

            int id;
            if (!int.TryParse(textBox9.Text, out id))
            {
                MessageBox.Show("מספר לקוח חייב להיות מספר");
                return;
            }

            Customer db = new Customer();
            if (!db.Found(id))
            {
                MessageBox.Show("לא נמצא לקוח בעל מספר זה" + " " + id);
            }
            else
            {
                DataTable ds = db.GetInfoByIdKey(id).Tables[0];
                textBox1.Text = ds.Rows[0]["costumerId"].ToString();
                textBox6.Text = ds.Rows[0]["customerLastName"].ToString();
                textBox8.Text = ds.Rows[0]["customerFirstName"].ToString();
                textBox2.Text = ds.Rows[0]["customerAddress"].ToString();
                textBox3.Text = ds.Rows[0]["customerPhoneNum"].ToString();
                textBox4.Text = ds.Rows[0]["customerCity"].ToString();
                textBox5.Text = ds.Rows[0]["customerEmail"].ToString();
                comboBox1.Text = ds.Rows[0]["customerDbMonth"].ToString();
            }
        }

        // כפתור הוסף - הוספת לקוח חדש
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox6.Text == "" || textBox8.Text == "" ||
                textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" ||
                textBox5.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("נא למלא את כל השדות");
                return;
            }

            if (!emailIsValid(textBox5.Text))
            {
                MessageBox.Show("אימייל חייב להיות בתבנית: example@something.com");
                return;
            }

            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show("מספר לקוח חייב להיות מספר");
                return;
            }

            Customer db = new Customer();
            if (db.Found(id))
            {
                MessageBox.Show("לקוח עם מספר זה כבר קיים במערכת");
                return;
            }

            Customer newCustomer = new Customer();
            newCustomer.PersonId = id;
            newCustomer.PersonLastName = textBox6.Text;
            newCustomer.PersonFirstName = textBox8.Text;
            newCustomer.PersonAddress = textBox2.Text;
            newCustomer.PersonPhoneNum = textBox3.Text;
            newCustomer.PersonCity = textBox4.Text;
            newCustomer.PersonEmail = textBox5.Text;
            newCustomer.CustomerDbMonth = Convert.ToInt32(comboBox1.Text);

            newCustomer.Insert();
            MessageBox.Show("הלקוח נוסף בהצלחה");
            dataGridView1.DataSource = DbMain.GetAllRecord("customer").Tables[0];
        }

        // כפתור מחק - מחיקת לקוח נבחר מהטבלה
        private void buttonDelet_Click_1(object sender, EventArgs e)
        {
            DataRow dr = GetSelectedRow();
            if (dr == null)
            {
                MessageBox.Show("נא לבחור רשומה למחיקה");
                return;
            }

            if (MessageBox.Show("האם למחוק את הלקוח?", "אישור מחיקה", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Customer db = new Customer();
                db.Delete(Convert.ToInt32(dr["costumerId"]));
                MessageBox.Show("הלקוח נמחק בהצלחה");
                dataGridView1.DataSource = DbMain.GetAllRecord("customer").Tables[0];
            }
        }

        // כפתור עדכן - עדכון פרטי לקוח קיים
        private void updateButton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox6.Text == "" || textBox8.Text == "" ||
                textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" ||
                textBox5.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("נא למלא את כל השדות");
                return;
            }

            if (!emailIsValid(textBox5.Text))
            {
                MessageBox.Show("אימייל חייב להיות בתבנית: example@something.com");
                return;
            }

            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show("מספר לקוח חייב להיות מספר");
                return;
            }

            Customer db = new Customer();
            if (!db.Found(id))
            {
                MessageBox.Show("לא נמצא לקוח בעל מספר זה לעדכון");
                return;
            }

            Customer editCustomers = new Customer();
            editCustomers.PersonId = id;
            editCustomers.PersonLastName = textBox6.Text;
            editCustomers.PersonFirstName = textBox8.Text;
            editCustomers.PersonAddress = textBox2.Text;
            editCustomers.PersonPhoneNum = textBox3.Text;
            editCustomers.PersonCity = textBox4.Text;
            editCustomers.PersonEmail = textBox5.Text;
            editCustomers.CustomerDbMonth = Convert.ToInt32(comboBox1.Text);

            editCustomers.Update();
            MessageBox.Show("פרטי הלקוח עודכנו בהצלחה");
            dataGridView1.DataSource = DbMain.GetAllRecord("customer").Tables[0];
        }

        private DataRow GetSelectedRow()
        {
            DataTable dt = null;
            if (dataGridView1.DataSource is DataTable)
                dt = dataGridView1.DataSource as DataTable;
            else if (dataGridView1.DataSource is BindingSource)
                dt = ((DataSet)((BindingSource)dataGridView1.DataSource).DataSource).Tables[0];
            else
                return null;

            if (dataGridView1.CurrentRow == null)
                return null;

            return dt.Rows[dataGridView1.CurrentRow.Index];
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }
    }
}

