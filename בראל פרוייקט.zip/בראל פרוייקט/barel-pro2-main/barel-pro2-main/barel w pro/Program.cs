﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
// ייבוא מרחב השמות של הטפסים כדי להכיר את supplierForm1 ו-GAMEForm1
using barel_w_pro.forms;

namespace barel_w_pro
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            // ----------------------------------------------------

            // 1. אפשרות להפעלת טופס הספקים:
          // Application.Run(new supplierForm1());

            // 2. אפשרות להפעלת טופס המשחקים:
           Application.Run(new login()); 

            // 3. אפשרות להפעלת טופס הלקוחות (הנוכחי):
            // Application.Run(new CustomersForm()); 
        }
    }
}