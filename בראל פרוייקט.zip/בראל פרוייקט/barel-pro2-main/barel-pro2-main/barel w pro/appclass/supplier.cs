﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace barel_w_pro.appclass
{
    class supplier
    {
        // -------------------------------------------
        // 1. תכונות (Properties) - תואמות לטבלת supplier
        // -------------------------------------------
        public int SupplierID { get; set; }        // מפתח ראשי
        public string CompanyName { get; set; }    // תואם לעמודה 'supplierChainName' (שם חברה/גוף)
        public string ContactName { get; set; }    // תואם לעמודה 'supplierContactNum' (שם איש קשר)
        public string PhoneNumber { get; set; }    // תואם לעמודה 'phoneNUM'

        // -------------------------------------------
        // 2. בנאים (Constructors)
        // -------------------------------------------
        public supplier() { }

        public supplier(int id, string companyName, string contactName, string phone)
        {
            this.SupplierID = id;
            this.CompanyName = companyName;
            this.ContactName = contactName;
            this.PhoneNumber = phone;
        }

        // -------------------------------------------
        // 3. שאילתות SQL
        // -------------------------------------------

        // הוספת ספק חדש
        public string GetInsertSQL()
        {
            // שים לב לשמות העמודות המדויקים באקסס בתוך ה-SQL
            return "INSERT INTO supplier (supplierID, supplierChainName, supplierContactNum, phoneNUM) " +
                   "VALUES (" + this.SupplierID + ", '" + this.CompanyName + "', '" + this.ContactName + "', '" + this.PhoneNumber + "')";
        }

        // עדכון פרטי ספק
        public string GetUpdateSQL()
        {
            return "UPDATE supplier SET " +
                   "supplierChainName = '" + this.CompanyName + "', " +
                   "supplierContactNum = '" + this.ContactName + "', " +
                   "phoneNUM = '" + this.PhoneNumber + "' " +
                   "WHERE supplierID = " + this.SupplierID;
        }

        // מחיקת ספק
        public string GetDeleteSQL()
        {
            return "DELETE FROM supplier WHERE supplierID = " + this.SupplierID;
        }

        // שליפת כל הספקים
        public static string GetAllSuppliersSQL()
        {
            return "SELECT * FROM supplier";
        }
    }
}