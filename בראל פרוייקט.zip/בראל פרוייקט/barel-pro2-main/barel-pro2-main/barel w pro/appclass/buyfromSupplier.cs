﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace barel_w_pro.appclass
{
    class buyFromSupplier
    {
        public int SupplierID { get; set; }
        public int ItemID { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchaseDate { get; set; }

        public buyFromSupplier() { }

        public buyFromSupplier(int supplierId, int itemId, int quantity, DateTime purchaseDate)
        {
            this.SupplierID = supplierId;
            this.ItemID = itemId;
            this.Quantity = quantity;
            this.PurchaseDate = purchaseDate;
        }

        // שאילתת הוספת רכישה מספק
        public string GetInsertSQL()
        {
            return "INSERT INTO buyFromSupplier (supplierID, itemID, quantity, purchaseDate) " +
                   "VALUES (" + this.SupplierID + ", " + this.ItemID + ", " +
                   this.Quantity + ", '" + this.PurchaseDate.ToShortDateString() + "')";
        }

        // שליפת כל הרכישות שבוצעו מספק ספציפי
        public static string GetPurchasesBySupplierSQL(int supplierId)
        {
            return "SELECT * FROM buyFromSupplier WHERE supplierID = " + supplierId;
        }

        public static string GetAllPurchasesSQL()
        {
            return "SELECT * FROM buyFromSupplier";
        }
    }
}