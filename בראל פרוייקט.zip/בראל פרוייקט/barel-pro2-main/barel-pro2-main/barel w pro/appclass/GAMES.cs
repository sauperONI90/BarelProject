﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace barel_w_pro.appclass
{
    class GAMES
    {
        // -------------------------------------------
        // 1. תכונות (Properties) - תואמות לטבלת GAMES
        // -------------------------------------------
        public int ItemID { get; set; }        // תואם לעמודה 'itemID'
        public string GameName { get; set; }   // תואם לעמודה 'gameName'
        public int Quantity { get; set; }      // תואם לעמודה 'quantity'
        public string Genre { get; set; }      // תואם לעמודה 'ganre'
        public int SupplierID { get; set; }    // תואם לעמודה 'supplierID'
        public double Price { get; set; }      // תואם לעמודה 'price'

        // -------------------------------------------
        // 2. בנאים (Constructors)
        // -------------------------------------------
        public GAMES() { }

        public GAMES(int itemId, string name, int qty, string genre, int supId, double price)
        {
            this.ItemID = itemId;
            this.GameName = name;
            this.Quantity = qty;
            this.Genre = genre;
            this.SupplierID = supId;
            this.Price = price;
        }

        // -------------------------------------------
        // 3. שאילתות SQL
        // -------------------------------------------

        // מחזירה שאילתה להוספת המשחק הנוכחי
        public string GetInsertSQL()
        {
            // שם העמודה המדויק הוא itemID
            return "INSERT INTO GAMES (itemID, gameName, quantity, ganre, supplierID, price) " +
                   "VALUES (" + this.ItemID + ", '" + this.GameName + "', " + this.Quantity + ", '" +
                   this.Genre + "', " + this.SupplierID + ", " + this.Price + ")";
        }

        // מחזירה שאילתה לעדכון המשחק הנוכחי
        public string GetUpdateSQL()
        {
            return "UPDATE GAMES SET " +
                   "gameName = '" + this.GameName + "', " +
                   "quantity = " + this.Quantity + ", " +
                   "ganre = '" + this.Genre + "', " +
                   "supplierID = " + this.SupplierID + ", " +
                   "price = " + this.Price + " " +
                   "WHERE itemID = " + this.ItemID; // שינוי ל-itemID
        }

        // מחזירה שאילתה למחיקת המשחק
        public string GetDeleteSQL()
        {
            return "DELETE FROM GAMES WHERE itemID = " + this.ItemID; // שינוי ל-itemID
        }

        // שליפת כל המשחקים
        public static string GetAllGamesSQL()
        {
            return "SELECT * FROM GAMES";
        }
    }
}