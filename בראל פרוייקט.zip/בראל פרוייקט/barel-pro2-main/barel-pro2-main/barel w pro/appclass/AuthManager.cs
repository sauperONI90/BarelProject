﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barel_w_pro.appclass
{
    class AuthManager
    {
    }
}
