﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace barel_w_pro.appclass
{
    class sales
    {
        // -------------------------------------------
        // 1. תכונות (Properties) - תואמות לטבלת sales ב-Access
        // -------------------------------------------
        public int SalesID { get; set; }        // מפתח ראשי
        public DateTime SalesDate { get; set; } // תאריך ושעת המכירה
        public int CustomerID { get; set; }     // מפתח זר לטבלת customer (עודכן מ-ClientID)
        public int? WorkerID { get; set; }      // מפתח זר לטבלת worker - מאפשר Null
        public double Total { get; set; }       // סכום המכירה הכולל

        // -------------------------------------------
        // 2. בנאים (Constructors)
        // -------------------------------------------
        public sales() { }

        public sales(int salesId, DateTime date, int customerId, int? workerId, double total)
        {
            this.SalesID = salesId;
            this.SalesDate = date;
            this.CustomerID = customerId;
            this.WorkerID = workerId;
            this.Total = total;
        }

        // -------------------------------------------
        // 3. שאילתות SQL
        // -------------------------------------------

        // הוספת מכירה חדשה
        public string GetInsertSQL()
        {
            // טיפול בערך null עבור WorkerID כדי שלא תהיה שגיאה ב-SQL
            string workerVal = (this.WorkerID == null) ? "NULL" : this.WorkerID.ToString();

            // ב-Access משתמשים ב-# עבור תאריכים
            return "INSERT INTO sales (salesID, salesDate, customerID, workerID, total) " +
                   "VALUES (" + this.SalesID + ", #" + this.SalesDate.ToString("MM/dd/yyyy HH:mm:ss") + "#, " +
                   this.CustomerID + ", " + workerVal + ", " + this.Total + ")";
        }

        // עדכון פרטי מכירה קיימת
        public string GetUpdateSQL()
        {
            string workerVal = (this.WorkerID == null) ? "NULL" : this.WorkerID.ToString();

            return "UPDATE sales SET " +
                   "salesDate = #" + this.SalesDate.ToString("MM/dd/yyyy HH:mm:ss") + "#, " +
                   "customerID = " + this.CustomerID + ", " +
                   "workerID = " + workerVal + ", " +
                   "total = " + this.Total + " " +
                   "WHERE salesID = " + this.SalesID;
        }

        // מחיקת מכירה
        public string GetDeleteSQL()
        {
            return "DELETE FROM sales WHERE salesID = " + this.SalesID;
        }

        // שליפת כל המכירות
        public static string GetAllSalesSQL()
        {
            return "SELECT * FROM sales";
        }
    }
}