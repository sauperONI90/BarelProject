﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using System.IO;


namespace barel_w_pro
{
    class DbMain
    {
        public static string DatabasePath
        {
            get
            {
                string fixedProjectDb = Path.GetFullPath(Path.Combine(Application.StartupPath, @"..\..\access\db2.accdb"));

                if (!File.Exists(fixedProjectDb))
                {
                    throw new FileNotFoundException("קובץ בסיס הנתונים לא נמצא בנתיב הקבוע: " + fixedProjectDb);
                }

                return fixedProjectDb;
            }
        }

        public static string ConnectionString
        {
            get { return "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DatabasePath + ";Persist Security Info=False"; }
        }

        public static void InsDelUpd(string SqlStr)
        {
            InsDelUpdRows(SqlStr);
        }

        public static int InsDelUpdRows(string SqlStr)
        {
            OleDbConnection cnn = new OleDbConnection();
            OleDbCommand cmd = new OleDbCommand();
            int rowsAffected = 0;

            cnn.ConnectionString = ConnectionString;

            try
            {
                cnn.Open();
                cmd.Connection = cnn;
                cmd.CommandText = SqlStr;
                rowsAffected = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("שגיאת DB: " + ex.Message + "\n\nSQL: " + SqlStr);
            }
            finally
            {
                cnn.Close();
            }
            return rowsAffected;
        }
        /*    טענת כניסה: הפונקציה מקבלת מחרוזת שליפה  
                DataSet טענת יציאה: הפונקציה מחזירה
         */
        public static  DataSet ReturnDS(string SqlStr)
        {
            DataSet ds = new DataSet();
            OleDbCommand cmd = new OleDbCommand();
            OleDbConnection cnn = new OleDbConnection();
            cnn.ConnectionString = ConnectionString;

            try
            {
                //  sql מאפיין אשר מאפשר לקבוע או לקבל את הוראת :CommandText
                cmd.CommandText = SqlStr;
                //  OleDbConnection מאפיין אשר מאפשר לקבוע או לקבל את אובייקט ההתחברות מהמחלקה :Connection
                cmd.Connection = cnn;
                //DataSet ומשימה שנייה בכדי לעדכן את בסיס הנתונים בהתאם למידע שהתרחש ב  DataSet יצירת מופע למחלקה המייצגת אובייקט ההתחברות לבסיס הנתונים. ייצוג זה דרוש לשתי משימות משימה ראשונה בכדי להעביר נתונים מבסיס הנתונים ל 
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                // DataSet טוענת את הנתונים לתוך אובייקט  Fill המתודה 
                da.Fill(ds);
            }
            catch (Exception e)
            { MessageBox.Show(e.Message); }
            finally
            {
                cnn.Close();
            }
            return ds;
        }

        // tableName  הפונקציה מחזירה את כל הרשומות  בטבלה  
        public  static DataSet GetAllRecord(string  tableName)
        {
            DataSet ds = new DataSet();

            OleDbCommand cmd = new OleDbCommand();
            OleDbConnection cnn = new OleDbConnection();
            cnn.ConnectionString = ConnectionString;
            try
            {
                cmd.CommandText = "select * from " + tableName;
                cmd.Connection = cnn;
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                  da.Fill(ds);
            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { cnn.Close(); }
            return ds;
        }

        //  SQL    הפונקציה מחזירה נתונים לפי מחרוזת שליפה    
        public static DataSet GetQuery(string sql)
        {
            DataSet ds = new DataSet();

            OleDbCommand cmd = new OleDbCommand();
            OleDbConnection cnn = new OleDbConnection();
            cnn.ConnectionString = ConnectionString;
            try
            {
                cmd.CommandText = sql;
                cmd.Connection = cnn;
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(ds);
            }
            catch (OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally { cnn.Close(); }
            return ds;
        }
    }
}

