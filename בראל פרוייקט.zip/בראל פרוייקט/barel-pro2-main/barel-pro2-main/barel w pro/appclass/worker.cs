﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace barel_w_pro.appclass
{
    public class worker
    {
        // תכונות המחלקה (Properties)
        public int WorkerId { get; set; }
        public string WorkerName { get; set; }

        // בנאי (Constructor) ריק - נדרש לעבודה עם מסדי נתונים ו-Entity Framework
        public worker()
        {
        }

        // בנאי עם פרמטרים לנוחות
        public worker(int id, string name)
        {
            this.WorkerId = id;
            this.WorkerName = name;
        }

        // שיטה אופציונלית להצגת פרטי העובד כמחרוזת
        public override string ToString()
        {
            return $"ID: {WorkerId}, Name: {WorkerName}";
        }
    }
}