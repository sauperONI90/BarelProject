﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace barel_w_pro.appclass
{
    class salesDetails
    {
        // -------------------------------------------
        // 1. תכונות (Properties)
        // -------------------------------------------
        public int SalesID { get; set; }
        public int ItemID { get; set; }
        public int Quantity { get; set; }
        public double PriceAtSale { get; set; }

        // -------------------------------------------
        // 2. בנאים (Constructors)
        // -------------------------------------------
        public salesDetails() { }

        public salesDetails(int salesId, int itemId, int quantity, double priceAtSale)
        {
            this.SalesID = salesId;
            this.ItemID = itemId;
            this.Quantity = quantity;
            this.PriceAtSale = priceAtSale;
        }

        // -------------------------------------------
        // 3. שאילתות SQL
        // -------------------------------------------

        public string GetInsertSQL()
        {
            return "INSERT INTO salesDetails (salesID, itemID, quantity, priceAtSale) " +
                   "VALUES (" + this.SalesID + ", " + this.ItemID + ", " +
                   this.Quantity + ", " + this.PriceAtSale + ")";
        }

        public string GetUpdateSQL()
        {
            return "UPDATE salesDetails SET " +
                   "quantity = " + this.Quantity + ", " +
                   "priceAtSale = " + this.PriceAtSale + " " +
                   "WHERE salesID = " + this.SalesID + " AND itemID = " + this.ItemID;
        }

        public string GetDeleteSQL()
        {
            return "DELETE FROM salesDetails WHERE salesID = " + this.SalesID +
                   " AND itemID = " + this.ItemID;
        }

        public static string GetDetailsBySalesID(int salesId)
        {
            return "SELECT * FROM salesDetails WHERE salesID = " + salesId;
        }

        public static string GetAllSalesDetailsSQL()
        {
            return "SELECT * FROM salesDetails";
        }
    }
}